<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/broadcasting/auth' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KmkZBUZbnIWLgNwj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jagte0gKYKXI9RnK',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/saldo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wRLhyjr18nsZz4io',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/saldo-deposit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Jtzeig2Zeh7fmVTA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/saldo-tarik' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jqk2Rnisdv0SpmQK',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/saldo-upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tKCvaJhVMnJL9eUi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/saldo-upload-info' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZoR8gd50dIBMKCEn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tkKwxpeStfAJX3f0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/pinjaman' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::k9Y8QYZ8yFC7IPHm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/pinjaman-history' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PKQVheAgsssSzfrQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/pinjaman-kode' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jRJGVCHdI6LfBhry',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/pinjaman-angsuran' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BXUnyBYnHZZQvfIj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/angsuran' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Na1f3WTIvthhQ6gV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/angsuran-lunas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NlZngRdJYFB908YS',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/angsuran-upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HFx2IrPB4PyukZDl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/angsuran-upload-info' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7Kbl3Si9QLjeyOWb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/notifikasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YUHGs8EjKJimcq0t',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/notifikasi-unread' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sfjyx6aokGU8LpXZ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/show-notification-penjualan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KVUuHLe2UyEdn0Q1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 't-login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/login/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::15thlQCasT7nTlDs',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/register/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::799PajaNRdpbO6OH',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SMlvulbZfddyB1eR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RTfiHKoJT0DSUtwn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4sJXdVTJRCbeUXeL',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pembelian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NscKqFPR5Xyb6ZY6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pembelian/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::s84NO8RpjnuecFW4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pembelian/beli' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aJkl3pVKjajhOiDt',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pembelian/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cgULZsVbXPMDfC7M',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pembelian/nota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bMhCYn3BNcKc1Yfq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::K6EGldwiDxqrAA9Q',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan/scan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6byApup2ZmLOgX5s',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FGd5xa6DIf8WwrAx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan/jual' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::chFFofqNdkWQBJzM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5n39ZPVJPDVBRB5O',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan/nota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ToW5MgFtjyknLzHm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/retur-pembelian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ubn3uWRcCPHmG3O9',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/retur-pembelian/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ECZbDEKnBhnZjjpU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/retur-pembelian/retur' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BPZqP4SXtosXFaew',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/retur-pembelian/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LY2kbiaXpS979e3D',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/retur-pembelian/nota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::miXgtkMmWMHFKqam',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/hutang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oTnVxRWObwGqkzTL',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/hutang/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GF0xZ8n0GaMG5tdS',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/hutang/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ScJv1N5ncjh349sh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/konsinyasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AnxgTOf6PoX9k3j9',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/konsinyasi/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gIhZC83hC0WrfMe6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/konsinyasi/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::t5kR5mxXHVqhpF0f',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/piutang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QK5MnBUhAxni0WMX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/piutang/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OTnB04J7WJJ2YZJK',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/piutang/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0CM6WMxuVhklVUw2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/titip-jual' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Es49LuUPI7XbmWiX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/titip-jual/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jykBaODWoTV6fzhg',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/titip-jual/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ii5SoZ16C0EnTV4f',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/titip-jual/buy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1EKfiv4IapUMr8hs',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/titip-jual/nota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::E28MuuIkmd7KH9h1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Yl6hI0DyX0Z7ozqN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal-umum' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yt42dri9mfvi6h7l',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal-umum/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iP57uJ79aonCuLt9',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal-umum/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FF2bst1psJuByznE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal-umum/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ov78eQ8Gqaf7Azql',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal-umum/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lbZpv8r73R7uHKR0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pesanan-online' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oRsOxbrhtllQ4EiG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pesanan-online/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WYtKmnJbBE8dmCiW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pesanan-online/pickup' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FzvdaX1hY43w61Tm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pesanan-online/batal-pickup' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::g0eKHuZxHBWzPpkP',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/persediaan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i46bYTPOBH25PWSj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/anggota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MclMrl75UBy1pc76',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/data-master' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2AVbCu1uMKNvclFV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/pembelian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EMPTZFyRDWENwiaq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/retur-pembelian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8wcWSi52VadRlOoK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/penjualan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nZMFwhWZhVLXaBZo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/persediaan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pPhyQkmXfSngiKCu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/persediaan/minimal-persediaan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pVtPkWn6Rg0EYJP9',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/kas-masuk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GuESOASCzVQujldg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/kas-keluar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XRa5qr4qxRMMSslE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/pendapatan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8278togcCFhCHofF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/piutang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5vdBD6pJak6WRaJY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/barang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NOzs8Gf6X5rSZGKg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/barang/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PcM0XqMQJZN5MH6O',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/barang/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FL9Bb4Vwf0EV6OFh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/barang/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GgQAKN1IugD5bHQM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/barang/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IRNibgpsbpK9lh4K',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mtJCvzneWGX0sL2W',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/admin/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mSxIIbYcl1oy2xTy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/admin/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::37X0nl00QTx8b1fm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/admin/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CfEuUUbrPMZ0cX59',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/admin/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jU51lJkz43VwXHtv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/akun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::poxh2BawnNLhkHax',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/akun/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D6k2t7XRgikweACW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/akun/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ofgV122NBYwoBINd',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/akun/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ny5IaCYvqXXZ4BSb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/akun/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AZzXZeyR51xjyCst',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/anggota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DUC9B1epJYUKP62B',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/anggota/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ibG9UWI3Tawhu55e',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/anggota/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::X90QvtmvebhvxBh2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/anggota/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::o2iDtOOeaXD999eY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/anggota/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9gpJudtBnGCjn1aU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/supplier' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Vm8zgXlelJQ2F9jY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/supplier/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HPs6kZDc6k9TiXlO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/supplier/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Z9W0f2wr32FFREjn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/supplier/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XmiuM9LSXM530LVr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/supplier/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HFkpQ5p4cluS43nq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/route-cache' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0UVV8CQt9Eni4Q76',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/config-cache' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pudMGykEVMXWOOQ6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cache-clear' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::amagZ0VaNzdiVIjd',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 's-login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/postlogin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'post-login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 's-logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XqT7DxFR14P8thIS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/delete-simpanan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete.simpanan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/delete-pinjaman' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete.pinjaman',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/delete-angsuran-tempo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete.angsuran-tempo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/anggota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/anggota/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/akun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'akun.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/akun/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/admin/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'data.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/data/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/saldo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/saldo/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/riwayat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.history',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/tarik-saldo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/tarik-saldo/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/pengajuan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/pengajuan/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/angsuran' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/angsuran/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/tempo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/tempo/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/jurnal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/jurnal/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/anggota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data-anggota.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/anggota/cetak/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data-anggota.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/simpanan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-simpanan.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/simpanan/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-simpanan.show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/simpanan/cetak/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-simpanan.print-all',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/pinjaman' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-pinjaman.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/pinjaman/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-pinjaman.show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/pinjaman/cetak/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-pinjaman.print-all',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/shu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'shu.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/shu/cetak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'shu.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/shu/show-data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'shu.show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/buku-besar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'buku-besar.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/buku-besar/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'buku-besar.show-data',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/buku-besar/cetak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'buku-besar.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/ekuitas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ekuitas.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/ekuiats/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ekuitas.show-data',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/ekuitas/cetak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ekuitas.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/keuangan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/keuangan/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.show-data',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/keuangan/cetak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/bendahara' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'bendahara.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/bendahara/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'bendahara.show-data',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/bendahara/cetak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'bendahara.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'list.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/list/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/pembagian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/pembagian/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/notif' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'clear-notif',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/all-notif' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'all-notif',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/delete-notif' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-notif',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/(?|simpan\\-pinjam/notifikasi/(?|([^/]++)(*:52)|delete(*:65))|data\\-(?|a(?|kun/([^/]++)(*:98)|nggota/([^/]++)(*:120))|b(?|arang/([^/]++)(*:147)|eli\\-barang/([^/]++)(*:175))|retur\\-(?|barang/([^/]++)(*:209)|detail\\-barang/([^/]++)/([^/]++)(*:249)|supplier/([^/]++)(*:274))|supplier/([^/]++)(*:300)|hutang\\-supplier/([^/]++)(*:333))|kode\\-admin/([^/]++)(*:362)|nomor\\-(?|pe(?|mbelian/([^/]++)(*:401)|njualan/([^/]++)(*:425))|jurnal\\-(?|pe(?|mbelian/([^/]++)(*:466)|njualan/([^/]++)(*:490))|retur\\-pembelian/([^/]++)(*:524)|angsuran/([^/]++)(*:549)|t(?|erima\\-piutang/([^/]++)(*:584)|itip\\-jual/([^/]++)(*:611))|konsinyasi/([^/]++)(*:639)|umum/([^/]++)(*:660))|retur\\-pembelian/([^/]++)(*:694)|angsuran/([^/]++)(*:719)|t(?|erima\\-piutang/([^/]++)(*:754)|itip\\-jual/([^/]++)(*:781))|konsinyasi/([^/]++)(*:809)))|/toko/(?|transaksi/(?|p(?|e(?|mbelian/(?|([^/]++)(*:868)|delete/([^/]++)(*:891))|njualan/(?|([^/]++)(*:919)|delete/([^/]++)(*:942))|sanan\\-online/(?|nota/([^/]++)(*:981)|proses/([^/]++)/([^/]++)(*:1013)))|iutang/(?|([^/]++)(*:1042)|delete/([^/]++)(*:1066)))|retur\\-pembelian/(?|([^/]++)(*:1105)|delete/([^/]++)(*:1129))|hutang/(?|([^/]++)(*:1157)|delete/([^/]++)(*:1181)|remove\\-notification/([^/]++)(*:1219))|konsinyasi/(?|([^/]++)(*:1251)|delete/([^/]++)(*:1275))|titip\\-jual/(?|([^/]++)(*:1308)|delete/([^/]++)(*:1332))|jurnal\\-umum/(?|([^/]++)(*:1366)|delete/([^/]++)(*:1390)))|laporan/(?|anggota/(?|print/([^/]++)/([^/]++)(*:1446)|export/([^/]++)/([^/]++)(*:1479)|detail/([^/]++)/([^/]++)/([^/]++)(*:1521))|data\\-master/(?|print/([^/]++)(*:1561)|export/([^/]++)(*:1585))|p(?|e(?|mbelian/(?|nota/([^/]++)(*:1627)|print/([^/]++)/([^/]++)/([^/]++)(*:1668)|export/([^/]++)/([^/]++)/([^/]++)(*:1710))|n(?|jualan/(?|nota/([^/]++)(*:1747)|print/([^/]++)/([^/]++)/([^/]++)(*:1788)|export/([^/]++)/([^/]++)/([^/]++)(*:1830))|dapatan/(?|print/([^/]++)/([^/]++)(*:1874)|export/([^/]++)/([^/]++)(*:1907)))|rsediaan/(?|print/([^/]++)(*:1944)|export/([^/]++)(*:1968)))|iutang/(?|print/([^/]++)/([^/]++)(*:2012)|export/([^/]++)/([^/]++)(*:2045)))|retur\\-pembelian/(?|nota/([^/]++)(*:2089)|print/([^/]++)(*:2112)|export/([^/]++)(*:2136))|kas\\-(?|masuk/(?|print/([^/]++)/([^/]++)/([^/]++)(*:2195)|export/([^/]++)/([^/]++)/([^/]++)(*:2237))|keluar/(?|print/([^/]++)/([^/]++)/([^/]++)(*:2289)|export/([^/]++)/([^/]++)/([^/]++)(*:2331))))|master/barang/(?|barcode/([^/]++)(*:2376)|remove\\-notification/([^/]++)(*:2414)))|/simpan\\-pinjam/(?|master/a(?|nggota/(?|([^/]++)(?|(*:2476)|/edit(*:2490)|(*:2499))|modal/([^/]++)(*:2523)|cetak/([^/]++)(*:2546))|kun/(?|([^/]++)(?|(*:2574)|/edit(*:2588)|(*:2597))|modal/([^/]++)(*:2621))|dmin/(?|([^/]++)(?|(*:2650)|/edit(*:2664)|(*:2673))|modal/([^/]++)(*:2697)))|simpanan/(?|data/(?|([^/]++)(?|(*:2739)|/edit(*:2753)|(*:2762))|cetak/(?|([^/]++)(*:2789)|show/([^/]++)(*:2811)|modal/([^/]++)(*:2834))|store\\-all(*:2854)|konfirmasi/([^/]++)(*:2882)|edit\\-all/([^/]++)(*:2909)|image/([^/]++)(*:2932))|saldo/([^/]++)(?|(*:2959)|/edit(*:2973)|(*:2982))|riwayat/cetak/(?|([^/]++)(*:3017)|show/([^/]++)(*:3039))|tarik\\-saldo/(?|([^/]++)(?|(*:3076)|/edit(*:3090)|(*:3099))|modal/(?|([^/]++)(*:3126)|delete/([^/]++)(*:3150))|saldo(*:3165)))|p(?|injaman/(?|pengajuan/(?|([^/]++)(?|(*:3215)|/edit(*:3229)|(*:3238))|konfirmasi/([^/]++)(*:3267)|cetak/(?|([^/]++)(*:3293)|show/([^/]++)(*:3315))|modal/([^/]++)(*:3339)|limit(*:3353))|angsuran/(?|([^/]++)(?|(*:3386)|/edit(*:3400)|(*:3409))|bayar(*:3424)|cetak/show/([^/]++)(*:3452)|konfirmasi/([^/]++)(*:3480)|modal/([^/]++)(*:3503)|store\\-all(*:3522)|update\\-bayar(*:3544))|tempo/(?|([^/]++)(?|(*:3574)|/edit(*:3588)|(*:3597))|bayar(*:3612)|cetak/show/([^/]++)(*:3640)|konfirmasi/([^/]++)(*:3668)|modal/([^/]++)(*:3691)|image/([^/]++)(*:3714)))|engaturan/(?|list/(?|([^/]++)(?|(*:3757)|/edit(*:3771)|(*:3780))|modal\\-all/([^/]++)(*:3809))|pembagian/(?|([^/]++)(?|(*:3843)|/edit(*:3857)|(*:3866))|modal/([^/]++)(*:3890))))|laporan/(?|jurnal/(?|([^/]++)(?|(*:3934)|/edit(*:3948)|(*:3957))|cetak(*:3972)|modal/([^/]++)(*:3995))|simpanan/cetak/show/([^/]++)(*:4033)|pinjaman/cetak/show/([^/]++)(*:4070))))/?$}sDu',
    ),
    3 => 
    array (
      52 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PwcCDWAgSZ4ASskB',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      65 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OrsySILeu4Wrlrf8',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      98 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yaA8NzOZORELWEmh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      120 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::czGbPeCmFMdvKNjX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      147 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lrD0BhJGm4WeLEEv',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      175 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BuV6Wxu8yuMSjSyk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      209 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Jurf0XU3C4dOzh3W',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      249 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kbswP5bC1hGPtJRU',
          ),
          1 => 
          array (
            0 => 'nomor',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      274 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zJ4saYuVRWwSpsGh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      300 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::99uhPiT3rdh5gVtU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      333 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RPZYqePAOuSMr2si',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      362 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iZzCQQPnwfKrn03x',
          ),
          1 => 
          array (
            0 => 'jabatan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      401 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::phfHzKXrHmsUxsRA',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      425 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::velExOelwI7nW2SM',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      466 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ERDQd3SiXf1A1Zfs',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      490 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CLKuMaCMYMTImoUL',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      524 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YagiXqOWE2QrMBe7',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      549 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nvUthJkfrnr7OpoA',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      584 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::P19lVYILoDIeSPNr',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      611 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AJ7WXIU5chqkHgzd',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      639 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QT6qyfJp9T8lX9GT',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      660 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YFbQpuacXFhQ3dA9',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      694 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SLuJbyGeWL27beAS',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      719 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PhZ67mVQqQUwqPz0',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      754 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Whu0nFDnnBMVPdB3',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      781 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eP6hKdK2K6oKB5mG',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      809 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::75wF8JmgXnBPcNq6',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      868 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Fd7JlAPYorsULtzG',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      891 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::27yXaehlQkCFyR5P',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      919 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NoIzFBuSnZcuePhq',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      942 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XltT8OiwEBk5bHn8',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      981 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7d1gwcWidlxZXNEN',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1013 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ql12T8bGApuuHIHr',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'proses',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1042 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ls9RyS4qFKQTL3nr',
          ),
          1 => 
          array (
            0 => 'nomor_jual',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1066 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TuA2EPvI4g1kqCx7',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1105 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::83xH3UhEeaTRIbBz',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1129 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fwknXXv6XgAnKVdp',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1157 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::y0kpnkgTW6VBvolC',
          ),
          1 => 
          array (
            0 => 'nomor_beli',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1181 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oVRIunT41PJ0TpMH',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1219 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WYcynyrj4ZjBvC1F',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1251 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LRAFrOT83Ci3J4NM',
          ),
          1 => 
          array (
            0 => 'nomor_titip_jual',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1275 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OxQgewpuVN6At1hM',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1308 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tb4KhmrLrsyl7H9d',
          ),
          1 => 
          array (
            0 => 'nomor_jual',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1332 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2okXI5n8PjVJIU0J',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1366 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NJ4JtQgJn47wp2V3',
          ),
          1 => 
          array (
            0 => 'nomor_jual',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1390 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xlYHiGfhBgB7Ar7d',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1446 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nDVbnPQOpUxdF6YD',
          ),
          1 => 
          array (
            0 => 'tanggal_awal',
            1 => 'tanggal_akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1479 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GOFZIgOzVKpRT0mt',
          ),
          1 => 
          array (
            0 => 'tanggal_awal',
            1 => 'tanggal_akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1521 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::s2Y3gF80W7AP4Y4X',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'tanggal_awal',
            2 => 'tanggal_akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1561 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XhI6tZ0oQjM9wTbY',
          ),
          1 => 
          array (
            0 => 'bagian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1585 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RIWEzmNzGCXS1Lg7',
          ),
          1 => 
          array (
            0 => 'bagian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1627 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qcvF5aikljYbBeQk',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1668 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wcsipBFxSx7P25L5',
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1710 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Q8eLpU4el9Jkz5Bg',
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1747 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jbO2DGbabegnOrC1',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1788 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wyd5qyHpYOjEjAAs',
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1830 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vZ3vd1oWkMAFscAa',
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1874 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bIhLSa1zceZtiDNA',
          ),
          1 => 
          array (
            0 => 'tanggal_awal',
            1 => 'tanggal_akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1907 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TBitxh4Jl0dHIQLM',
          ),
          1 => 
          array (
            0 => 'tanggal_awal',
            1 => 'tanggal_akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1944 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fXTio458OcoYEPBD',
          ),
          1 => 
          array (
            0 => 'stok',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1968 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y8JW8DtSFTCxH7Rt',
          ),
          1 => 
          array (
            0 => 'stok',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2012 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8cKNUY4wnfLudS7I',
          ),
          1 => 
          array (
            0 => 'awal',
            1 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2045 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XM4834P64kams4LA',
          ),
          1 => 
          array (
            0 => 'awal',
            1 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2089 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kyCQlXxJtNl1lJms',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2112 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::myHCwsZrIfgXzYdd',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2136 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::b0yY5U5Qlyo0lqCv',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2195 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8n1XjkOObgMnRcQK',
          ),
          1 => 
          array (
            0 => 'jenis',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2237 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::117ZsAxPS7vb9nvg',
          ),
          1 => 
          array (
            0 => 'jenis',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2289 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bA2pW3HTmzvrwJJt',
          ),
          1 => 
          array (
            0 => 'jenis',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2331 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::COIzolPKcsWXA6BF',
          ),
          1 => 
          array (
            0 => 'jenis',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2376 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yCnbbHGFZV3pQ0R2',
          ),
          1 => 
          array (
            0 => 'kode',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2414 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IzEzNYiTFetOabMq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2476 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.show',
          ),
          1 => 
          array (
            0 => 'anggotum',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2490 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.edit',
          ),
          1 => 
          array (
            0 => 'anggotum',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2499 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.update',
          ),
          1 => 
          array (
            0 => 'anggotum',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.destroy',
          ),
          1 => 
          array (
            0 => 'anggotum',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2523 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2546 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.print',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2574 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.show',
          ),
          1 => 
          array (
            0 => 'akun',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2588 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.edit',
          ),
          1 => 
          array (
            0 => 'akun',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2597 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.update',
          ),
          1 => 
          array (
            0 => 'akun',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'akun.destroy',
          ),
          1 => 
          array (
            0 => 'akun',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2621 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2650 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.show',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2664 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2673 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.update',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.destroy',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2697 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2739 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.show',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2753 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.edit',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2762 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.update',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'data.destroy',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2789 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.print',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2811 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2834 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2854 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.store-all',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2882 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2909 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.edit-all',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2932 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.image',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2959 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.show',
          ),
          1 => 
          array (
            0 => 'saldo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2973 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.edit',
          ),
          1 => 
          array (
            0 => 'saldo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2982 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.update',
          ),
          1 => 
          array (
            0 => 'saldo',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.destroy',
          ),
          1 => 
          array (
            0 => 'saldo',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3017 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.print',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3039 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3076 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.show',
          ),
          1 => 
          array (
            0 => 'tarik_saldo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3090 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.edit',
          ),
          1 => 
          array (
            0 => 'tarik_saldo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3099 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.update',
          ),
          1 => 
          array (
            0 => 'tarik_saldo',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.destroy',
          ),
          1 => 
          array (
            0 => 'tarik_saldo',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3126 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3150 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.modal-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3165 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.saldo',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3215 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.show',
          ),
          1 => 
          array (
            0 => 'pengajuan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3229 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.edit',
          ),
          1 => 
          array (
            0 => 'pengajuan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3238 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.update',
          ),
          1 => 
          array (
            0 => 'pengajuan',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.destroy',
          ),
          1 => 
          array (
            0 => 'pengajuan',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3267 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3293 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.print',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3315 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3339 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3353 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.limit',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3386 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.show',
          ),
          1 => 
          array (
            0 => 'angsuran',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3400 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.edit',
          ),
          1 => 
          array (
            0 => 'angsuran',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3409 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.update',
          ),
          1 => 
          array (
            0 => 'angsuran',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.destroy',
          ),
          1 => 
          array (
            0 => 'angsuran',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3424 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.bayar',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3452 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3480 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3503 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3522 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.store-all',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3544 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.update-bayar',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3574 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.show',
          ),
          1 => 
          array (
            0 => 'tempo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3588 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.edit',
          ),
          1 => 
          array (
            0 => 'tempo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3597 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.update',
          ),
          1 => 
          array (
            0 => 'tempo',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.destroy',
          ),
          1 => 
          array (
            0 => 'tempo',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3612 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.bayar',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3640 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3668 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3691 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3714 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.image',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3757 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.show',
          ),
          1 => 
          array (
            0 => 'list',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3771 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.edit',
          ),
          1 => 
          array (
            0 => 'list',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3780 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.update',
          ),
          1 => 
          array (
            0 => 'list',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'list.destroy',
          ),
          1 => 
          array (
            0 => 'list',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3809 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.modal-all',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3843 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.show',
          ),
          1 => 
          array (
            0 => 'pembagian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3857 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.edit',
          ),
          1 => 
          array (
            0 => 'pembagian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3866 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.update',
          ),
          1 => 
          array (
            0 => 'pembagian',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.destroy',
          ),
          1 => 
          array (
            0 => 'pembagian',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3890 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3934 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.show',
          ),
          1 => 
          array (
            0 => 'jurnal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3948 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.edit',
          ),
          1 => 
          array (
            0 => 'jurnal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3957 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.update',
          ),
          1 => 
          array (
            0 => 'jurnal',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.destroy',
          ),
          1 => 
          array (
            0 => 'jurnal',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3972 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.print-show',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3995 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4033 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-simpanan.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4070 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-pinjaman.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::KmkZBUZbnIWLgNwj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'broadcasting/auth',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Broadcasting\\BroadcastController@authenticate',
        'controller' => '\\Illuminate\\Broadcasting\\BroadcastController@authenticate',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'excluded_middleware' => 
        array (
          0 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
        ),
        'as' => 'generated::KmkZBUZbnIWLgNwj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jagte0gKYKXI9RnK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\API\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::jagte0gKYKXI9RnK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wRLhyjr18nsZz4io' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@index',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@index',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::wRLhyjr18nsZz4io',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Jtzeig2Zeh7fmVTA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/saldo-deposit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@deposit',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@deposit',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::Jtzeig2Zeh7fmVTA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jqk2Rnisdv0SpmQK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/saldo-tarik',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@withdraw',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@withdraw',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::jqk2Rnisdv0SpmQK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tKCvaJhVMnJL9eUi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/saldo-upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@upload_transfer',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@upload_transfer',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::tKCvaJhVMnJL9eUi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZoR8gd50dIBMKCEn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/saldo-upload-info',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@upload_info',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@upload_info',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::ZoR8gd50dIBMKCEn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tkKwxpeStfAJX3f0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PengaturanController@index',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PengaturanController@index',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::tkKwxpeStfAJX3f0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::k9Y8QYZ8yFC7IPHm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/pinjaman',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@index',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@index',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::k9Y8QYZ8yFC7IPHm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::PKQVheAgsssSzfrQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/pinjaman-history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@history',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@history',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::PKQVheAgsssSzfrQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jRJGVCHdI6LfBhry' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/pinjaman-kode',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@kode',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@kode',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::jRJGVCHdI6LfBhry',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::BXUnyBYnHZZQvfIj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/pinjaman-angsuran',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran_pinjaman',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran_pinjaman',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::BXUnyBYnHZZQvfIj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Na1f3WTIvthhQ6gV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/angsuran',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::Na1f3WTIvthhQ6gV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NlZngRdJYFB908YS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/angsuran-lunas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran_lunas',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran_lunas',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::NlZngRdJYFB908YS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HFx2IrPB4PyukZDl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/angsuran-upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@upload_transfer_angsuran',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@upload_transfer_angsuran',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::HFx2IrPB4PyukZDl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7Kbl3Si9QLjeyOWb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/angsuran-upload-info',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@upload_info_angsuran',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@upload_info_angsuran',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::7Kbl3Si9QLjeyOWb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YUHGs8EjKJimcq0t' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/notifikasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@index',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@index',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::YUHGs8EjKJimcq0t',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::sfjyx6aokGU8LpXZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/notifikasi-unread',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@unread',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@unread',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::sfjyx6aokGU8LpXZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::PwcCDWAgSZ4ASskB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/notifikasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@detail',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@detail',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::PwcCDWAgSZ4ASskB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OrsySILeu4Wrlrf8' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/simpan-pinjam/notifikasi/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@delete',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@delete',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::OrsySILeu4Wrlrf8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yaA8NzOZORELWEmh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-akun/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataAkunController@dataAkun',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataAkunController@dataAkun',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::yaA8NzOZORELWEmh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lrD0BhJGm4WeLEEv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-barang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataBarang',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataBarang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::lrD0BhJGm4WeLEEv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::BuV6Wxu8yuMSjSyk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-beli-barang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataBeliBarang',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataBeliBarang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::BuV6Wxu8yuMSjSyk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Jurf0XU3C4dOzh3W' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-retur-barang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataReturBarang',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataReturBarang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::Jurf0XU3C4dOzh3W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kbswP5bC1hGPtJRU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-retur-detail-barang/{nomor}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataReturDetailBarang',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataReturDetailBarang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::kbswP5bC1hGPtJRU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::99uhPiT3rdh5gVtU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-supplier/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataSupplier',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataSupplier',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::99uhPiT3rdh5gVtU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zJ4saYuVRWwSpsGh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-retur-supplier/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataReturSupplier',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataReturSupplier',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::zJ4saYuVRWwSpsGh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RPZYqePAOuSMr2si' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-hutang-supplier/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataHutangSupplier',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataHutangSupplier',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::RPZYqePAOuSMr2si',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::czGbPeCmFMdvKNjX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-anggota/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataAnggotaController@dataAnggota',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataAnggotaController@dataAnggota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::czGbPeCmFMdvKNjX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KVUuHLe2UyEdn0Q1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/show-notification-penjualan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@showNotification',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@showNotification',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::KVUuHLe2UyEdn0Q1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::iZzCQQPnwfKrn03x' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/kode-admin/{jabatan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\KodeAdminController@kodeAdmin',
        'controller' => 'App\\Http\\Controllers\\Toko\\KodeAdminController@kodeAdmin',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::iZzCQQPnwfKrn03x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::phfHzKXrHmsUxsRA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-pembelian/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorPembelian',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorPembelian',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::phfHzKXrHmsUxsRA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ERDQd3SiXf1A1Zfs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-pembelian/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalPembelian',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalPembelian',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::ERDQd3SiXf1A1Zfs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SLuJbyGeWL27beAS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-retur-pembelian/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorReturPembelian',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorReturPembelian',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::SLuJbyGeWL27beAS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YagiXqOWE2QrMBe7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-retur-pembelian/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalReturPembelian',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalReturPembelian',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::YagiXqOWE2QrMBe7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::velExOelwI7nW2SM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-penjualan/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorPenjualan',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorPenjualan',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::velExOelwI7nW2SM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CLKuMaCMYMTImoUL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-penjualan/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalPenjualan',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalPenjualan',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::CLKuMaCMYMTImoUL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::PhZ67mVQqQUwqPz0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-angsuran/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorAngsuran',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorAngsuran',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::PhZ67mVQqQUwqPz0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::nvUthJkfrnr7OpoA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-angsuran/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalAngsuran',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalAngsuran',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::nvUthJkfrnr7OpoA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Whu0nFDnnBMVPdB3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-terima-piutang/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorTerimaPiutang',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorTerimaPiutang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::Whu0nFDnnBMVPdB3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::P19lVYILoDIeSPNr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-terima-piutang/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalTerimaPiutang',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalTerimaPiutang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::P19lVYILoDIeSPNr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::eP6hKdK2K6oKB5mG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-titip-jual/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorTitipJual',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorTitipJual',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::eP6hKdK2K6oKB5mG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AJ7WXIU5chqkHgzd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-titip-jual/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalTitipJual',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalTitipJual',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::AJ7WXIU5chqkHgzd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::75wF8JmgXnBPcNq6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-konsinyasi/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorKonsinyasi',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorKonsinyasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::75wF8JmgXnBPcNq6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::QT6qyfJp9T8lX9GT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-konsinyasi/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalKonsinyasi',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalKonsinyasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::QT6qyfJp9T8lX9GT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YFbQpuacXFhQ3dA9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-umum/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalUmum',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalUmum',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::YFbQpuacXFhQ3dA9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":256:{@In4qm3rHsI1h5zF/1wh8dTRJ8kuG2o2InVf8u5w6O04=.a:5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'index\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000048de85de000000001cf1b6c8";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    't-login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\AuthController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\AuthController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 't-login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::15thlQCasT7nTlDs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/login/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\Toko\\AuthController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'generated::15thlQCasT7nTlDs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\AuthController@register',
        'controller' => 'App\\Http\\Controllers\\Toko\\AuthController@register',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::799PajaNRdpbO6OH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/register/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\AuthController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\AuthController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'generated::799PajaNRdpbO6OH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SMlvulbZfddyB1eR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'generated::SMlvulbZfddyB1eR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RTfiHKoJT0DSUtwn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'generated::RTfiHKoJT0DSUtwn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::4sJXdVTJRCbeUXeL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\Toko\\AuthController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'generated::4sJXdVTJRCbeUXeL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NscKqFPR5Xyb6ZY6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/pembelian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::NscKqFPR5Xyb6ZY6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::s84NO8RpjnuecFW4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pembelian/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::s84NO8RpjnuecFW4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::aJkl3pVKjajhOiDt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pembelian/beli',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@buy',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@buy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::aJkl3pVKjajhOiDt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::cgULZsVbXPMDfC7M' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pembelian/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::cgULZsVbXPMDfC7M',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bMhCYn3BNcKc1Yfq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/pembelian/nota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::bMhCYn3BNcKc1Yfq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Fd7JlAPYorsULtzG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/pembelian/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::Fd7JlAPYorsULtzG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::27yXaehlQkCFyR5P' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pembelian/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::27yXaehlQkCFyR5P',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::K6EGldwiDxqrAA9Q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/penjualan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::K6EGldwiDxqrAA9Q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6byApup2ZmLOgX5s' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/penjualan/scan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@scan',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@scan',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::6byApup2ZmLOgX5s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FGd5xa6DIf8WwrAx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/penjualan/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::FGd5xa6DIf8WwrAx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::chFFofqNdkWQBJzM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/penjualan/jual',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@sell',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@sell',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::chFFofqNdkWQBJzM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5n39ZPVJPDVBRB5O' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/penjualan/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::5n39ZPVJPDVBRB5O',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ToW5MgFtjyknLzHm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/penjualan/nota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::ToW5MgFtjyknLzHm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NoIzFBuSnZcuePhq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/penjualan/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::NoIzFBuSnZcuePhq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XltT8OiwEBk5bHn8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/penjualan/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::XltT8OiwEBk5bHn8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ubn3uWRcCPHmG3O9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/retur-pembelian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::Ubn3uWRcCPHmG3O9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ECZbDEKnBhnZjjpU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::ECZbDEKnBhnZjjpU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::BPZqP4SXtosXFaew' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/retur',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@retur',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@retur',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::BPZqP4SXtosXFaew',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::LY2kbiaXpS979e3D' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::LY2kbiaXpS979e3D',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::miXgtkMmWMHFKqam' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/nota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::miXgtkMmWMHFKqam',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::83xH3UhEeaTRIbBz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::83xH3UhEeaTRIbBz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fwknXXv6XgAnKVdp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::fwknXXv6XgAnKVdp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oTnVxRWObwGqkzTL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/hutang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Gudang',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::oTnVxRWObwGqkzTL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GF0xZ8n0GaMG5tdS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/hutang/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Gudang',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::GF0xZ8n0GaMG5tdS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ScJv1N5ncjh349sh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/hutang/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Gudang',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::ScJv1N5ncjh349sh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::y0kpnkgTW6VBvolC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/hutang/{nomor_beli}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Gudang',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::y0kpnkgTW6VBvolC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oVRIunT41PJ0TpMH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/hutang/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Gudang',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::oVRIunT41PJ0TpMH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::WYcynyrj4ZjBvC1F' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/hutang/remove-notification/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Gudang',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@removeNotification',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@removeNotification',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::WYcynyrj4ZjBvC1F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AnxgTOf6PoX9k3j9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/konsinyasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/konsinyasi',
        'where' => 
        array (
        ),
        'as' => 'generated::AnxgTOf6PoX9k3j9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gIhZC83hC0WrfMe6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/konsinyasi/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/konsinyasi',
        'where' => 
        array (
        ),
        'as' => 'generated::gIhZC83hC0WrfMe6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::t5kR5mxXHVqhpF0f' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/konsinyasi/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/konsinyasi',
        'where' => 
        array (
        ),
        'as' => 'generated::t5kR5mxXHVqhpF0f',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::LRAFrOT83Ci3J4NM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/konsinyasi/{nomor_titip_jual}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/konsinyasi',
        'where' => 
        array (
        ),
        'as' => 'generated::LRAFrOT83Ci3J4NM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OxQgewpuVN6At1hM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/konsinyasi/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/konsinyasi',
        'where' => 
        array (
        ),
        'as' => 'generated::OxQgewpuVN6At1hM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::QK5MnBUhAxni0WMX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/piutang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::QK5MnBUhAxni0WMX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OTnB04J7WJJ2YZJK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/piutang/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::OTnB04J7WJJ2YZJK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0CM6WMxuVhklVUw2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/piutang/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::0CM6WMxuVhklVUw2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ls9RyS4qFKQTL3nr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/piutang/{nomor_jual}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::Ls9RyS4qFKQTL3nr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::TuA2EPvI4g1kqCx7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/piutang/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::TuA2EPvI4g1kqCx7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Es49LuUPI7XbmWiX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/titip-jual',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::Es49LuUPI7XbmWiX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jykBaODWoTV6fzhg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/titip-jual/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::jykBaODWoTV6fzhg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ii5SoZ16C0EnTV4f' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/titip-jual/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::ii5SoZ16C0EnTV4f',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::1EKfiv4IapUMr8hs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/titip-jual/buy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@buy',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@buy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::1EKfiv4IapUMr8hs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::E28MuuIkmd7KH9h1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/titip-jual/nota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::E28MuuIkmd7KH9h1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tb4KhmrLrsyl7H9d' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/titip-jual/{nomor_jual}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::tb4KhmrLrsyl7H9d',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2okXI5n8PjVJIU0J' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/titip-jual/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::2okXI5n8PjVJIU0J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Yl6hI0DyX0Z7ozqN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/jurnal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Jurnal\\JurnalController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Jurnal\\JurnalController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal',
        'where' => 
        array (
        ),
        'as' => 'generated::Yl6hI0DyX0Z7ozqN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yt42dri9mfvi6h7l' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/jurnal-umum',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::yt42dri9mfvi6h7l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::iP57uJ79aonCuLt9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::iP57uJ79aonCuLt9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FF2bst1psJuByznE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::FF2bst1psJuByznE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ov78eQ8Gqaf7Azql' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@save',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@save',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::Ov78eQ8Gqaf7Azql',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lbZpv8r73R7uHKR0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::lbZpv8r73R7uHKR0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NJ4JtQgJn47wp2V3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/{nomor_jual}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::NJ4JtQgJn47wp2V3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xlYHiGfhBgB7Ar7d' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::xlYHiGfhBgB7Ar7d',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oRsOxbrhtllQ4EiG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/pesanan-online',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pesanan-online',
        'where' => 
        array (
        ),
        'as' => 'generated::oRsOxbrhtllQ4EiG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::WYtKmnJbBE8dmCiW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pesanan-online/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pesanan-online',
        'where' => 
        array (
        ),
        'as' => 'generated::WYtKmnJbBE8dmCiW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FzvdaX1hY43w61Tm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pesanan-online/pickup',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@pickup',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@pickup',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pesanan-online',
        'where' => 
        array (
        ),
        'as' => 'generated::FzvdaX1hY43w61Tm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::g0eKHuZxHBWzPpkP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pesanan-online/batal-pickup',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@batalPickup',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@batalPickup',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pesanan-online',
        'where' => 
        array (
        ),
        'as' => 'generated::g0eKHuZxHBWzPpkP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7d1gwcWidlxZXNEN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/pesanan-online/nota/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pesanan-online',
        'where' => 
        array (
        ),
        'as' => 'generated::7d1gwcWidlxZXNEN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ql12T8bGApuuHIHr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pesanan-online/proses/{id}/{proses}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@proses',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@proses',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pesanan-online',
        'where' => 
        array (
        ),
        'as' => 'generated::Ql12T8bGApuuHIHr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::i46bYTPOBH25PWSj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/persediaan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Gudang',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Persediaan\\PersediaanController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Persediaan\\PersediaanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/persediaan',
        'where' => 
        array (
        ),
        'as' => 'generated::i46bYTPOBH25PWSj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MclMrl75UBy1pc76' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/anggota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::MclMrl75UBy1pc76',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::nDVbnPQOpUxdF6YD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/anggota/print/{tanggal_awal}/{tanggal_akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::nDVbnPQOpUxdF6YD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GOFZIgOzVKpRT0mt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/anggota/export/{tanggal_awal}/{tanggal_akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::GOFZIgOzVKpRT0mt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::s2Y3gF80W7AP4Y4X' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/anggota/detail/{id}/{tanggal_awal}/{tanggal_akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@detail',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@detail',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::s2Y3gF80W7AP4Y4X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2AVbCu1uMKNvclFV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/data-master',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/data-master',
        'where' => 
        array (
        ),
        'as' => 'generated::2AVbCu1uMKNvclFV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XhI6tZ0oQjM9wTbY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/data-master/print/{bagian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/data-master',
        'where' => 
        array (
        ),
        'as' => 'generated::XhI6tZ0oQjM9wTbY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RIWEzmNzGCXS1Lg7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/data-master/export/{bagian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/data-master',
        'where' => 
        array (
        ),
        'as' => 'generated::RIWEzmNzGCXS1Lg7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EMPTZFyRDWENwiaq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pembelian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::EMPTZFyRDWENwiaq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qcvF5aikljYbBeQk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pembelian/nota/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::qcvF5aikljYbBeQk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wcsipBFxSx7P25L5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pembelian/print/{type}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::wcsipBFxSx7P25L5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Q8eLpU4el9Jkz5Bg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pembelian/export/{type}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::Q8eLpU4el9Jkz5Bg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8wcWSi52VadRlOoK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/retur-pembelian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::8wcWSi52VadRlOoK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kyCQlXxJtNl1lJms' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/retur-pembelian/nota/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::kyCQlXxJtNl1lJms',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::myHCwsZrIfgXzYdd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/retur-pembelian/print/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::myHCwsZrIfgXzYdd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::b0yY5U5Qlyo0lqCv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/retur-pembelian/export/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::b0yY5U5Qlyo0lqCv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::nZMFwhWZhVLXaBZo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/penjualan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::nZMFwhWZhVLXaBZo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jbO2DGbabegnOrC1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/penjualan/nota/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::jbO2DGbabegnOrC1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wyd5qyHpYOjEjAAs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/penjualan/print/{type}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::wyd5qyHpYOjEjAAs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vZ3vd1oWkMAFscAa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/penjualan/export/{type}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::vZ3vd1oWkMAFscAa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::pPhyQkmXfSngiKCu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/persediaan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/persediaan',
        'where' => 
        array (
        ),
        'as' => 'generated::pPhyQkmXfSngiKCu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::pVtPkWn6Rg0EYJP9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/persediaan/minimal-persediaan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@minimalPersediaan',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@minimalPersediaan',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/persediaan',
        'where' => 
        array (
        ),
        'as' => 'generated::pVtPkWn6Rg0EYJP9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fXTio458OcoYEPBD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/persediaan/print/{stok}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/persediaan',
        'where' => 
        array (
        ),
        'as' => 'generated::fXTio458OcoYEPBD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Y8JW8DtSFTCxH7Rt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/persediaan/export/{stok}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/persediaan',
        'where' => 
        array (
        ),
        'as' => 'generated::Y8JW8DtSFTCxH7Rt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GuESOASCzVQujldg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-masuk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-masuk',
        'where' => 
        array (
        ),
        'as' => 'generated::GuESOASCzVQujldg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8n1XjkOObgMnRcQK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-masuk/print/{jenis}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-masuk',
        'where' => 
        array (
        ),
        'as' => 'generated::8n1XjkOObgMnRcQK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::117ZsAxPS7vb9nvg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-masuk/export/{jenis}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-masuk',
        'where' => 
        array (
        ),
        'as' => 'generated::117ZsAxPS7vb9nvg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XRa5qr4qxRMMSslE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-keluar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-keluar',
        'where' => 
        array (
        ),
        'as' => 'generated::XRa5qr4qxRMMSslE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bA2pW3HTmzvrwJJt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-keluar/print/{jenis}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-keluar',
        'where' => 
        array (
        ),
        'as' => 'generated::bA2pW3HTmzvrwJJt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::COIzolPKcsWXA6BF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-keluar/export/{jenis}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-keluar',
        'where' => 
        array (
        ),
        'as' => 'generated::COIzolPKcsWXA6BF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8278togcCFhCHofF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pendapatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pendapatan\\LaporanPendapatanController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pendapatan\\LaporanPendapatanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pendapatan',
        'where' => 
        array (
        ),
        'as' => 'generated::8278togcCFhCHofF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bIhLSa1zceZtiDNA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pendapatan/print/{tanggal_awal}/{tanggal_akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pendapatan\\LaporanPendapatanController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pendapatan\\LaporanPendapatanController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pendapatan',
        'where' => 
        array (
        ),
        'as' => 'generated::bIhLSa1zceZtiDNA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::TBitxh4Jl0dHIQLM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pendapatan/export/{tanggal_awal}/{tanggal_akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pendapatan\\LaporanPendapatanController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pendapatan\\LaporanPendapatanController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pendapatan',
        'where' => 
        array (
        ),
        'as' => 'generated::TBitxh4Jl0dHIQLM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5vdBD6pJak6WRaJY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/piutang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Piutang\\LaporanPiutangController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Piutang\\LaporanPiutangController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::5vdBD6pJak6WRaJY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8cKNUY4wnfLudS7I' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/piutang/print/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Piutang\\LaporanPiutangController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Piutang\\LaporanPiutangController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::8cKNUY4wnfLudS7I',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XM4834P64kams4LA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/piutang/export/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Piutang\\LaporanPiutangController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Piutang\\LaporanPiutangController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::XM4834P64kams4LA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NOzs8Gf6X5rSZGKg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/barang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::NOzs8Gf6X5rSZGKg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::PcM0XqMQJZN5MH6O' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/barang/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::PcM0XqMQJZN5MH6O',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FL9Bb4Vwf0EV6OFh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/barang/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::FL9Bb4Vwf0EV6OFh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GgQAKN1IugD5bHQM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/barang/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@update',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::GgQAKN1IugD5bHQM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::IRNibgpsbpK9lh4K' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/barang/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::IRNibgpsbpK9lh4K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yCnbbHGFZV3pQ0R2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/barang/barcode/{kode}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@barcode',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@barcode',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::yCnbbHGFZV3pQ0R2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::IzEzNYiTFetOabMq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/barang/remove-notification/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@removeNotification',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@removeNotification',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::IzEzNYiTFetOabMq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mtJCvzneWGX0sL2W' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::mtJCvzneWGX0sL2W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mSxIIbYcl1oy2xTy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/admin/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::mSxIIbYcl1oy2xTy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::37X0nl00QTx8b1fm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/admin/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::37X0nl00QTx8b1fm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CfEuUUbrPMZ0cX59' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/admin/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@update',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::CfEuUUbrPMZ0cX59',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jU51lJkz43VwXHtv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/admin/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::jU51lJkz43VwXHtv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::poxh2BawnNLhkHax' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/akun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/akun',
        'where' => 
        array (
        ),
        'as' => 'generated::poxh2BawnNLhkHax',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::D6k2t7XRgikweACW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/akun/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/akun',
        'where' => 
        array (
        ),
        'as' => 'generated::D6k2t7XRgikweACW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ofgV122NBYwoBINd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/akun/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/akun',
        'where' => 
        array (
        ),
        'as' => 'generated::ofgV122NBYwoBINd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ny5IaCYvqXXZ4BSb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/akun/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@update',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/akun',
        'where' => 
        array (
        ),
        'as' => 'generated::Ny5IaCYvqXXZ4BSb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AZzXZeyR51xjyCst' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/akun/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/akun',
        'where' => 
        array (
        ),
        'as' => 'generated::AZzXZeyR51xjyCst',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::DUC9B1epJYUKP62B' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/anggota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Kanit,Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::DUC9B1epJYUKP62B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ibG9UWI3Tawhu55e' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/anggota/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Kanit,Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::ibG9UWI3Tawhu55e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::X90QvtmvebhvxBh2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/anggota/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Kanit,Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::X90QvtmvebhvxBh2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::o2iDtOOeaXD999eY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/anggota/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Kanit,Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@update',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::o2iDtOOeaXD999eY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9gpJudtBnGCjn1aU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/anggota/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Kanit,Super_Admin,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::9gpJudtBnGCjn1aU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Vm8zgXlelJQ2F9jY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/supplier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::Vm8zgXlelJQ2F9jY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HPs6kZDc6k9TiXlO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/supplier/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::HPs6kZDc6k9TiXlO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Z9W0f2wr32FFREjn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/supplier/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::Z9W0f2wr32FFREjn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XmiuM9LSXM530LVr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/supplier/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@update',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::XmiuM9LSXM530LVr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HFkpQ5p4cluS43nq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/supplier/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::HFkpQ5p4cluS43nq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0UVV8CQt9Eni4Q76' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'route-cache',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":328:{@k2+mvHndQ28XCsY3b4qeEaUbk+zoTs8e7wH3xRoRkkU=.a:5:{s:3:"use";a:0:{}s:8:"function";s:115:"function () {
    \\Illuminate\\Support\\Facades\\Artisan::call(\'route:cache\');
    return \'Routes cache cleared\';
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000048de85ed000000001cf1b6c8";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::0UVV8CQt9Eni4Q76',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::pudMGykEVMXWOOQ6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'config-cache',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":329:{@Qfu+1u3VhapHtyTMPZeK8O9bcC0+It+o8eNjxbRDcaU=.a:5:{s:3:"use";a:0:{}s:8:"function";s:116:"function () {
    \\Illuminate\\Support\\Facades\\Artisan::call(\'config:cache\');
    return \'Config cache cleared\';
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000048de85e6000000001cf1b6c8";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::pudMGykEVMXWOOQ6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::amagZ0VaNzdiVIjd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cache-clear',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":333:{@n/ilV1qzrqKk9+Y6z8zN44NpgUP6SbZuPK6HwUppfvc=.a:5:{s:3:"use";a:0:{}s:8:"function";s:120:"function () {
    \\Illuminate\\Support\\Facades\\Artisan::call(\'cache:clear\');
    return \'Application cache cleared\';
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000048de8662000000001cf1b6c8";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::amagZ0VaNzdiVIjd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    's-login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 's-login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'post-login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/postlogin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@post_login',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@post_login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'post-login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    's-logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 's-logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XqT7DxFR14P8thIS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":279:{@fSDI0fhSz2WftjZxZpgFy4NXAVELx2Bfscd8iVOUI9Y=.a:5:{s:3:"use";a:0:{}s:8:"function";s:67:"function () {
        return \\redirect()->route(\'s-login\');
    }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000048de8699000000001cf1b6c8";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::XqT7DxFR14P8thIS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'delete.simpanan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/delete-simpanan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@delete_simpanan',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@delete_simpanan',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'delete.simpanan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'delete.pinjaman' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/delete-pinjaman',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@delete_pinjaman',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@delete_pinjaman',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'delete.pinjaman',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'delete.angsuran-tempo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/delete-angsuran-tempo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@delete_angsuran',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@delete_angsuran',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'delete.angsuran-tempo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Dashboard\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Dashboard\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/master/anggota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota/{anggotum}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota/{anggotum}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/master/anggota/{anggotum}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/master/anggota/{anggotum}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
        'as' => 'anggota.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota/cetak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@print',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
        'as' => 'anggota.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/akun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/akun/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/master/akun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/akun/{akun}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/akun/{akun}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/master/akun/{akun}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/master/akun/{akun}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/akun/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
        'as' => 'akun.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/admin/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/master/admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/admin/{admin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/admin/{admin}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/master/admin/{admin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/master/admin/{admin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/admin/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
        'as' => 'admin.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/simpanan/data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/{data}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/cetak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@print',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/cetak/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.store-all' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/store-all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@store_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@store_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.store-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/konfirmasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@konfirmasi',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@konfirmasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.edit-all' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/edit-all/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@edit_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@edit_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.edit-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.image' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/image/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@modal_image',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@modal_image',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.image',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo/{saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo/{saldo}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo/{saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo/{saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.history' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/riwayat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@history',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@history',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.history',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/riwayat/cetak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@print',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/riwayat/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/{tarik_saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/{tarik_saldo}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/{tarik_saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/{tarik_saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.modal-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/modal/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@modal_delete',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@modal_delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.modal-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.saldo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@saldo',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@saldo',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.saldo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/{pengajuan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/{pengajuan}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/{pengajuan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/{pengajuan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/konfirmasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@konfirmasi',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@konfirmasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'pengajuan.konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/cetak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@print',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'pengajuan.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'pengajuan.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'pengajuan.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.limit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/limit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@limit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@limit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'pengajuan.limit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/{angsuran}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/{angsuran}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/{angsuran}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/{angsuran}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.bayar' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/bayar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@bayar',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@bayar',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.bayar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/konfirmasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@konfirmasi',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@konfirmasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.store-all' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/store-all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@store_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@store_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.store-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.update-bayar' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/update-bayar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@update_bayar',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@update_bayar',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.update-bayar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/{tempo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/{tempo}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/{tempo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/{tempo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.bayar' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/bayar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@bayar',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@bayar',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'tempo.bayar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'tempo.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/konfirmasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@konfirmasi',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@konfirmasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'tempo.konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'tempo.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.image' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/image/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@modal_image',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@modal_image',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'tempo.image',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/{jurnal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/{jurnal}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/{jurnal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/{jurnal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'jurnal.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'jurnal.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data-anggota.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/anggota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\DataAnggotaController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\DataAnggotaController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'data-anggota.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data-anggota.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/anggota/cetak/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\DataAnggotaController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\DataAnggotaController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'data-anggota.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-simpanan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/simpanan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-simpanan.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-simpanan.show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/simpanan/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-simpanan.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-simpanan.print-all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/simpanan/cetak/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@print_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@print_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-simpanan.print-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-simpanan.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/simpanan/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-simpanan.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-pinjaman.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/pinjaman',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-pinjaman.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-pinjaman.show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/pinjaman/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-pinjaman.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-pinjaman.print-all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/pinjaman/cetak/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@print_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@print_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-pinjaman.print-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-pinjaman.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/pinjaman/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-pinjaman.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'shu.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/shu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'shu.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'shu.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/shu/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'shu.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'shu.show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/shu/show-data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'shu.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'buku-besar.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/buku-besar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'buku-besar.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'buku-besar.show-data' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/buku-besar/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@show_data',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@show_data',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'buku-besar.show-data',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'buku-besar.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/buku-besar/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'buku-besar.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'ekuitas.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/ekuitas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'ekuitas.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'ekuitas.show-data' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/ekuiats/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@show_data',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@show_data',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'ekuitas.show-data',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'ekuitas.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/ekuitas/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'ekuitas.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/keuangan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'keuangan.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.show-data' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/keuangan/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@show_data',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@show_data',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'keuangan.show-data',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/keuangan/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'keuangan.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'bendahara.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/bendahara',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BendaharaController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BendaharaController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'bendahara.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'bendahara.show-data' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/bendahara/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BendaharaController@show_data',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BendaharaController@show_data',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'bendahara.show-data',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'bendahara.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/bendahara/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BendaharaController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BendaharaController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'bendahara.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/{list}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/{list}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/{list}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/{list}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.modal-all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/modal-all/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@modal_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@modal_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
        'as' => 'list.modal-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pembagian.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pembagian.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pembagian.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian/{pembagian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pembagian.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian/{pembagian}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pembagian.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian/{pembagian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pembagian.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian/{pembagian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pembagian.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
        'as' => 'pembagian.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'clear-notif' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pengaturan/notif',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\NotifikasiController@clear',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\NotifikasiController@clear',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
        'as' => 'clear-notif',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'all-notif' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/all-notif',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\NotifikasiController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\NotifikasiController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
        'as' => 'all-notif',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'delete-notif' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/delete-notif',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\NotifikasiController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\NotifikasiController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
        'as' => 'delete-notif',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
