<footer class="footer align-middle">
    <p class="copyright">
        Copyright &copy; 2021
        <a href="" class="text-primary text-decoration-none text-wrap">Kompak Polines.</a>
        All rights reserved.
    </p>
</footer>