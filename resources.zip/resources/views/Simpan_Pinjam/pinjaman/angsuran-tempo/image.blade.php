<div class="modal-header">
    <h5 class="modal-title">Bukti Transfer</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">
    <div class="text-center">
        <img src="{{ asset('storage/transfer/' . $angsuran->image) }}" alt="Bukti Transfer"
            style="max-height: 300px;">
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-light" data-dismiss="modal">Tutup</button>
</div>
