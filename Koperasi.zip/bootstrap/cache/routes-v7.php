<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/broadcasting/auth' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wKCbUpTurc4JjAiV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kwmQBGiySP7iXXx3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/saldo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RhNDG1hWIJVHLW55',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/saldo-deposit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AXVPCAg5fDZbjLkM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/saldo-tarik' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KHrBucijfPiBbfGu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/saldo-upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RUukCEV5PC6aSEIL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/saldo-upload-info' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EYwhQdGuiYH9ODPo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kLyOxsL2FiIOzmwv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/pinjaman' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rIMtAUoHWPX3STZX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/pinjaman-history' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LdSJtSYZkXCUETE6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/pinjaman-kode' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i5kgxCzj50N6f39r',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/pinjaman-angsuran' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gcY7O4uBX76CqT7n',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/angsuran' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::V5biW61BQhREy6oJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/angsuran-lunas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KMPbDN18DdOpgSTa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/angsuran-upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8Sa3jY3S1qJBMI4j',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/angsuran-upload-info' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RhPWsQVu4KlAefUI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/notifikasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2nFpFGdQLNiUxPwa',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/notifikasi-unread' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f4hwcwNhYx71RHO1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/show-notification-penjualan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xGNa574XwapHXYrG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 't-login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/login/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::p86fSwDm7CzcUJ5k',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/register/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wACGygB5BEXV7FRZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R28SiUWlmHwdkMLm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FfFy6E3ZrMtJ8nC7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kS0GGLkAKsqqxhYm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pembelian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WKCJxVLfPhsvBCFo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pembelian/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D7no64gjnACarM3f',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pembelian/beli' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pfgbPjBG03UUa69w',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pembelian/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uLtp0TBWjYen8ZBj',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pembelian/nota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hXeUTx2X9jz2oFox',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zPqAPwqu7eJuIt0F',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan/scan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yVy5egwJ3Nsfgh8g',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZWGSPyRU3N9wRaL4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan/jual' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3sjD3RmywVxNZNbS',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gTLTCR1Yvv8zbihn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan/nota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Q1hRsLlETmbXbpXs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/retur-pembelian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TCpW7Hbzcm07GMbG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/retur-pembelian/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rdDB28oJrHv672vy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/retur-pembelian/retur' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5HzreNgOsVGL1UyH',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/retur-pembelian/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mfd6DTdPg7fs7Pof',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/retur-pembelian/nota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Vt8hP0oROrIx7lzZ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/hutang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::onRVcOLgPTJSoEtw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/hutang/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UQcBMsjod3K9GNTI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/hutang/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZwygNJoE9CDPgaYr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/konsinyasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MVwMNgPZqW1aXY6g',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/konsinyasi/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ydFXvPyDN5fb5f6h',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/konsinyasi/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y2oGRz8NkeHJdtzD',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/piutang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::phVIkqecpRbLfEK0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/piutang/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8SfvDU9MQrYfx2t1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/piutang/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::L7Cvs48lZU64F2JM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/titip-jual' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wO15QtdHwMVcuV35',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/titip-jual/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bykYoJAKkK10qvyk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/titip-jual/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TAStt6lR6dDW3OWo',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/titip-jual/buy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f9dLQsov6nEIMqtW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/titip-jual/nota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oIevWzBuCDgnpfGc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9AljT86hAbW9o51S',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal-umum' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Vsp04xVc1FnOMOLp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal-umum/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gWVaNMSYhMTSpWUb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal-umum/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8Tol93wfYXHx8qQx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal-umum/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OUYIDGlBUN24Z0Fk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal-umum/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R3Iqb4oUY6iyNAqd',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pesanan-online' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::moThFlnwGORPjY2p',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pesanan-online/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kmmxpCM6cOFQtN0A',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pesanan-online/pickup' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::U6xY2jo9RNtSRUHV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pesanan-online/batal-pickup' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vaZRMCUmnAiQC2CF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/persediaan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OvXSb4Ls7bb0FHRd',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/anggota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UZQ3TcZWIrck00zv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/data-master' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xU8tRuaynnTQAjCd',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/pembelian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NgYXL2aXg6iwY5LO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/retur-pembelian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MxCT3UJvXZzaCFBB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/penjualan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KuJTDIuDmXiiPxuS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/persediaan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tQFn3apJShHAiRIP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/persediaan/minimal-persediaan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::L75t5qyj1xsFl3xc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/kas-masuk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kmjoLJB6wEzaqVGu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/kas-keluar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::X7Wr2v21QTRLlqVS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/pendapatan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::T9PxTAEsotg9MH5D',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/piutang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z8cifYbqFQm9D7py',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/barang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nZZqr3dsz0SznizF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/barang/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::k6Qznv2ec5xdL1OW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/barang/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lcr0g3RhOkLBBzZG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/barang/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KTHu5uEmdLfmdtE5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/barang/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KA8WCLbnAPE2VP4c',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iTCdpIJpfFfhrMyl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/admin/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rJur83z8dPVj3pC0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/admin/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WCmpojI0aS7QmyZN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/admin/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8KWGkNhmvxdnmeKP',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/admin/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DZbpUoaB3BoDJhfZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/akun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yzfiW2EpEIBwKKRZ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/akun/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8GAlk7bINRgt6AXq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/akun/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NzUF9M3U4JRsPC2O',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/akun/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rWynzWD18AlUFisM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/akun/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qxkv1pUMTi7dykqe',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/anggota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZisKZLBRfxjIa3Md',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/anggota/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nWSrljkNUF0Cu1Rr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/anggota/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dgoNp4B5KLvdr4Xl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/anggota/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QJV4Ta0WCKxUMZ5b',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/anggota/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Q6db2JyZBjRXWqh4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/supplier' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kraJhqGVzeviXTmX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/supplier/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aCD4QlN2U2EQ2Iaq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/supplier/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::U1ACkAaIhJr7n5zd',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/supplier/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pqmGNBC8lpZYaiki',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/supplier/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OTVmXV8v9rv6jQmL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/route-cache' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MgBpFv4XlakonQ8c',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/config-cache' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bVHg8qLA0rxH8fdy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cache-clear' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ka2w6IIkUXmiVA1a',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 's-login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/postlogin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'post-login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 's-logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0cO565mrmGoNEcYe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/delete-simpanan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete.simpanan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/delete-pinjaman' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete.pinjaman',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/delete-angsuran-tempo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete.angsuran-tempo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/anggota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/anggota/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/akun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'akun.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/akun/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/admin/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'data.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/data/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/saldo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/saldo/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/riwayat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.history',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/tarik-saldo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/tarik-saldo/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/pengajuan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/pengajuan/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/angsuran' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/angsuran/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/tempo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/tempo/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/jurnal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/jurnal/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/anggota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data-anggota.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/anggota/cetak/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data-anggota.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/simpanan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-simpanan.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/simpanan/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-simpanan.show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/simpanan/cetak/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-simpanan.print-all',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/pinjaman' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-pinjaman.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/pinjaman/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-pinjaman.show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/pinjaman/cetak/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-pinjaman.print-all',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/shu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'shu.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/shu/cetak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'shu.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/shu/show-data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'shu.show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/buku-besar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'buku-besar.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/buku-besar/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'buku-besar.show-data',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/buku-besar/cetak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'buku-besar.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/ekuitas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ekuitas.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/ekuitas/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ekuitas.show-data',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/ekuitas/cetak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ekuitas.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/keuangan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/keuangan/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.show-data',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/keuangan/cetak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/bendahara' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'bendahara.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/bendahara/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'bendahara.show-data',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/bendahara/cetak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'bendahara.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'list.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/list/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/pembagian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/pembagian/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/notif' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'clear-notif',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/all-notif' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'all-notif',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/delete-notif' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-notif',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/(?|simpan\\-pinjam/notifikasi/(?|([^/]++)(*:52)|delete(*:65))|data\\-(?|a(?|kun/([^/]++)(*:98)|nggota/([^/]++)(*:120))|b(?|arang/([^/]++)(*:147)|eli\\-barang/([^/]++)(*:175))|retur\\-(?|barang/([^/]++)(*:209)|detail\\-barang/([^/]++)/([^/]++)(*:249)|supplier/([^/]++)(*:274))|supplier/([^/]++)(*:300)|hutang\\-supplier/([^/]++)(*:333))|kode\\-admin/([^/]++)(*:362)|nomor\\-(?|pe(?|mbelian/([^/]++)(*:401)|njualan/([^/]++)(*:425))|jurnal\\-(?|pe(?|mbelian/([^/]++)(*:466)|njualan/([^/]++)(*:490))|retur\\-pembelian/([^/]++)(*:524)|angsuran/([^/]++)(*:549)|t(?|erima\\-piutang/([^/]++)(*:584)|itip\\-jual/([^/]++)(*:611))|konsinyasi/([^/]++)(*:639)|umum/([^/]++)(*:660))|retur\\-pembelian/([^/]++)(*:694)|angsuran/([^/]++)(*:719)|t(?|erima\\-piutang/([^/]++)(*:754)|itip\\-jual/([^/]++)(*:781))|konsinyasi/([^/]++)(*:809)))|/toko/(?|transaksi/(?|p(?|e(?|mbelian/(?|([^/]++)(*:868)|delete/([^/]++)(*:891))|njualan/(?|([^/]++)(*:919)|delete/([^/]++)(*:942))|sanan\\-online/(?|nota/([^/]++)(*:981)|proses/([^/]++)/([^/]++)(*:1013)))|iutang/(?|([^/]++)(*:1042)|delete/([^/]++)(*:1066)))|retur\\-pembelian/(?|([^/]++)(*:1105)|delete/([^/]++)(*:1129))|hutang/(?|([^/]++)(*:1157)|delete/([^/]++)(*:1181)|remove\\-notification/([^/]++)(*:1219))|konsinyasi/(?|([^/]++)(*:1251)|delete/([^/]++)(*:1275))|titip\\-jual/(?|([^/]++)(*:1308)|delete/([^/]++)(*:1332))|jurnal\\-umum/(?|([^/]++)(*:1366)|delete/([^/]++)(*:1390)))|laporan/(?|anggota/(?|print/([^/]++)/([^/]++)(*:1446)|export/([^/]++)/([^/]++)(*:1479)|detail/([^/]++)/([^/]++)/([^/]++)(*:1521))|data\\-master/(?|print/([^/]++)(*:1561)|export/([^/]++)(*:1585))|p(?|e(?|mbelian/(?|nota/([^/]++)(*:1627)|print/([^/]++)/([^/]++)/([^/]++)(*:1668)|export/([^/]++)/([^/]++)/([^/]++)(*:1710))|n(?|jualan/(?|nota/([^/]++)(*:1747)|print/([^/]++)/([^/]++)/([^/]++)(*:1788)|export/([^/]++)/([^/]++)/([^/]++)(*:1830))|dapatan/(?|print/([^/]++)/([^/]++)(*:1874)|export/([^/]++)/([^/]++)(*:1907)))|rsediaan/(?|print/([^/]++)(*:1944)|export/([^/]++)(*:1968)))|iutang/(?|print/([^/]++)/([^/]++)(*:2012)|export/([^/]++)/([^/]++)(*:2045)))|retur\\-pembelian/(?|nota/([^/]++)(*:2089)|print/([^/]++)(*:2112)|export/([^/]++)(*:2136))|kas\\-(?|masuk/(?|print/([^/]++)/([^/]++)/([^/]++)(*:2195)|export/([^/]++)/([^/]++)/([^/]++)(*:2237))|keluar/(?|print/([^/]++)/([^/]++)/([^/]++)(*:2289)|export/([^/]++)/([^/]++)/([^/]++)(*:2331))))|master/barang/(?|barcode/([^/]++)(*:2376)|remove\\-notification/([^/]++)(*:2414)))|/simpan\\-pinjam/(?|master/a(?|nggota/(?|([^/]++)(?|(*:2476)|/edit(*:2490)|(*:2499))|modal/([^/]++)(*:2523)|cetak/([^/]++)(*:2546))|kun/(?|([^/]++)(?|(*:2574)|/edit(*:2588)|(*:2597))|modal/([^/]++)(*:2621))|dmin/(?|([^/]++)(?|(*:2650)|/edit(*:2664)|(*:2673))|modal/([^/]++)(*:2697)))|simpanan/(?|data/(?|([^/]++)(?|(*:2739)|/edit(*:2753)|(*:2762))|cetak/(?|([^/]++)(*:2789)|show/([^/]++)(*:2811)|modal/([^/]++)(*:2834))|store\\-all(*:2854)|konfirmasi/([^/]++)(*:2882)|edit\\-all/([^/]++)(*:2909)|image/([^/]++)(*:2932))|saldo/([^/]++)(?|(*:2959)|/edit(*:2973)|(*:2982))|riwayat/cetak/(?|([^/]++)(*:3017)|show/([^/]++)(*:3039))|tarik\\-saldo/(?|([^/]++)(?|(*:3076)|/edit(*:3090)|(*:3099))|modal/(?|([^/]++)(*:3126)|delete/([^/]++)(*:3150))|saldo(*:3165)))|p(?|injaman/(?|pengajuan/(?|([^/]++)(?|(*:3215)|/edit(*:3229)|(*:3238))|konfirmasi/([^/]++)(*:3267)|cetak/(?|([^/]++)(*:3293)|show/([^/]++)(*:3315))|modal/([^/]++)(*:3339)|limit(*:3353))|angsuran/(?|([^/]++)(?|(*:3386)|/edit(*:3400)|(*:3409))|bayar(*:3424)|cetak/show/([^/]++)(*:3452)|konfirmasi/([^/]++)(*:3480)|modal/([^/]++)(*:3503)|store\\-all(*:3522)|update\\-bayar(*:3544))|tempo/(?|([^/]++)(?|(*:3574)|/edit(*:3588)|(*:3597))|bayar(*:3612)|cetak/show/([^/]++)(*:3640)|konfirmasi/([^/]++)(*:3668)|modal/([^/]++)(*:3691)|image/([^/]++)(*:3714)))|engaturan/(?|list/(?|([^/]++)(?|(*:3757)|/edit(*:3771)|(*:3780))|modal\\-all/([^/]++)(*:3809))|pembagian/(?|([^/]++)(?|(*:3843)|/edit(*:3857)|(*:3866))|modal/([^/]++)(*:3890))))|laporan/(?|jurnal/(?|([^/]++)(?|(*:3934)|/edit(*:3948)|(*:3957))|cetak(*:3972)|modal/([^/]++)(*:3995))|simpanan/cetak/show/([^/]++)(*:4033)|pinjaman/cetak/show/([^/]++)(*:4070))))/?$}sDu',
    ),
    3 => 
    array (
      52 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qm1ZDSPfLqAStDED',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      65 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4zbnLHviRTtDxOgP',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      98 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3Ck6OCo8hOyTip7n',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      120 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uGB3Vnw8TEW1LhmE',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      147 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zshN2cRAHzOoQXTN',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      175 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VAziPfpxQnvegnFB',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      209 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aR3uYl8LXYKCK84T',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      249 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7W2EPSMzR6WIwzLD',
          ),
          1 => 
          array (
            0 => 'nomor',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      274 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6b7d6dNEAAJu5GIk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      300 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gAnB6R40lGHD7SSk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      333 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::st662iD2Bl4gZPhT',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      362 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4khHUxYwAW059KTE',
          ),
          1 => 
          array (
            0 => 'jabatan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      401 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gbjDaAGAJJuhm3ee',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      425 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CZdBF0kpjethB7qS',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      466 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7x2QTWUsei2pE9lz',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      490 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HpbJT2Lk1AOL2pTH',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      524 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6q5CR78PEZ61v1Mp',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      549 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::X5uETkaZNTg6Xxx3',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      584 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l1apK3VSSY1HFTJr',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      611 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mvJgCs9iOG2qHdSj',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      639 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yCD2WyN6nBUVRHMD',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      660 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bl0ehTPGRkZgEVX4',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      694 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dXuLnaJ4DyvOwANd',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      719 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::P4EU92h6I7J8QRHh',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      754 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HlX2kEnGqsG1Tnvq',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      781 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nl2VCAIOw2uHkGh7',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      809 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::85YEqC3MTmi2KlD4',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      868 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ni4EwHo0mAHN9Kvw',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      891 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PTdTBCqLOMgFs01O',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      919 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sJ6HwPcBSOE9ktXs',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      942 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::t751Yhsa2B8eZiff',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      981 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jN8LF8cBuCdM3vP2',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1013 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EGD45GyDg4geopOi',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'proses',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1042 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h6gejjXtvERPKBQ5',
          ),
          1 => 
          array (
            0 => 'nomor_jual',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1066 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eiWJQrLY0nRBTiw1',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1105 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FrHhnKfstFg195lw',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1129 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EPL2dj2doxXkKCm9',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1157 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RZT441mVeVb18Le0',
          ),
          1 => 
          array (
            0 => 'nomor_beli',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1181 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uiVQXvNST8SLH5Zp',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1219 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EZSgKCROBte65ofu',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1251 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zMfgOJAtMQ7nriXR',
          ),
          1 => 
          array (
            0 => 'nomor_titip_jual',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1275 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Do94ktOcmcuytDbQ',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1308 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CAwSF72CdvCni1y8',
          ),
          1 => 
          array (
            0 => 'nomor_jual',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1332 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QV5pdJynQIjJ1w8W',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1366 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5ugaSKHcVUyDbzcF',
          ),
          1 => 
          array (
            0 => 'nomor_jual',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1390 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ncPLe2mviIf5NP2k',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1446 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3tEpMa9PRe7HORaT',
          ),
          1 => 
          array (
            0 => 'tanggal_awal',
            1 => 'tanggal_akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1479 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ozqhg5XrdGAfiogb',
          ),
          1 => 
          array (
            0 => 'tanggal_awal',
            1 => 'tanggal_akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1521 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1DgyHsHsKZq4uR8m',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'tanggal_awal',
            2 => 'tanggal_akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1561 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WfaBHeWfua35wsAD',
          ),
          1 => 
          array (
            0 => 'bagian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1585 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l7GTkz7Hn3h0F7eY',
          ),
          1 => 
          array (
            0 => 'bagian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1627 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::21H304qNgxlNiOrU',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1668 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QOuAaoEkpeXUWuVa',
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1710 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8YUinieIaht8POxR',
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1747 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Adhe7c4OA7ozOoBU',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1788 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SgGvSPVylHmAMJM9',
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1830 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qQBHKLZI5Vby1zqH',
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1874 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::V7nYnOK8L4hgdrBz',
          ),
          1 => 
          array (
            0 => 'tanggal_awal',
            1 => 'tanggal_akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1907 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GABmWobGGobbMkW6',
          ),
          1 => 
          array (
            0 => 'tanggal_awal',
            1 => 'tanggal_akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1944 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::09gI3bidiZBjNkX9',
          ),
          1 => 
          array (
            0 => 'stok',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1968 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::37E1jO4LUCz9IXmx',
          ),
          1 => 
          array (
            0 => 'stok',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2012 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Jh2PUTG4jmDZSV8f',
          ),
          1 => 
          array (
            0 => 'awal',
            1 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2045 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EfXeuQKrllx2WQ0d',
          ),
          1 => 
          array (
            0 => 'awal',
            1 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2089 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BKesJDmb1OlBzPEA',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2112 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vGial85FReRsgWmp',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2136 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D4kI2WkePNUgQKjz',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2195 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N88ertkXCVHgZOlV',
          ),
          1 => 
          array (
            0 => 'jenis',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2237 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gupfKko18VcM10vE',
          ),
          1 => 
          array (
            0 => 'jenis',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2289 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D27m7Q1Cef1Yv5n4',
          ),
          1 => 
          array (
            0 => 'jenis',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2331 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bNLoCaYIWmybfr7J',
          ),
          1 => 
          array (
            0 => 'jenis',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2376 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZYCI9bvCUGMFehXJ',
          ),
          1 => 
          array (
            0 => 'kode',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2414 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BkvQvyIIz7gQ8ZYa',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2476 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.show',
          ),
          1 => 
          array (
            0 => 'anggotum',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2490 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.edit',
          ),
          1 => 
          array (
            0 => 'anggotum',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2499 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.update',
          ),
          1 => 
          array (
            0 => 'anggotum',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.destroy',
          ),
          1 => 
          array (
            0 => 'anggotum',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2523 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2546 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.print',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2574 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.show',
          ),
          1 => 
          array (
            0 => 'akun',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2588 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.edit',
          ),
          1 => 
          array (
            0 => 'akun',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2597 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.update',
          ),
          1 => 
          array (
            0 => 'akun',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'akun.destroy',
          ),
          1 => 
          array (
            0 => 'akun',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2621 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2650 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.show',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2664 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2673 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.update',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.destroy',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2697 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2739 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.show',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2753 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.edit',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2762 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.update',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'data.destroy',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2789 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.print',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2811 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2834 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2854 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.store-all',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2882 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2909 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.edit-all',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2932 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.image',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2959 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.show',
          ),
          1 => 
          array (
            0 => 'saldo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2973 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.edit',
          ),
          1 => 
          array (
            0 => 'saldo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2982 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.update',
          ),
          1 => 
          array (
            0 => 'saldo',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.destroy',
          ),
          1 => 
          array (
            0 => 'saldo',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3017 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.print',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3039 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3076 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.show',
          ),
          1 => 
          array (
            0 => 'tarik_saldo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3090 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.edit',
          ),
          1 => 
          array (
            0 => 'tarik_saldo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3099 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.update',
          ),
          1 => 
          array (
            0 => 'tarik_saldo',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.destroy',
          ),
          1 => 
          array (
            0 => 'tarik_saldo',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3126 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3150 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.modal-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3165 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.saldo',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3215 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.show',
          ),
          1 => 
          array (
            0 => 'pengajuan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3229 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.edit',
          ),
          1 => 
          array (
            0 => 'pengajuan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3238 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.update',
          ),
          1 => 
          array (
            0 => 'pengajuan',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.destroy',
          ),
          1 => 
          array (
            0 => 'pengajuan',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3267 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3293 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.print',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3315 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3339 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3353 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.limit',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3386 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.show',
          ),
          1 => 
          array (
            0 => 'angsuran',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3400 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.edit',
          ),
          1 => 
          array (
            0 => 'angsuran',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3409 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.update',
          ),
          1 => 
          array (
            0 => 'angsuran',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.destroy',
          ),
          1 => 
          array (
            0 => 'angsuran',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3424 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.bayar',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3452 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3480 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3503 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3522 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.store-all',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3544 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.update-bayar',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3574 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.show',
          ),
          1 => 
          array (
            0 => 'tempo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3588 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.edit',
          ),
          1 => 
          array (
            0 => 'tempo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3597 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.update',
          ),
          1 => 
          array (
            0 => 'tempo',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.destroy',
          ),
          1 => 
          array (
            0 => 'tempo',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3612 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.bayar',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3640 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3668 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3691 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3714 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.image',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3757 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.show',
          ),
          1 => 
          array (
            0 => 'list',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3771 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.edit',
          ),
          1 => 
          array (
            0 => 'list',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3780 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.update',
          ),
          1 => 
          array (
            0 => 'list',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'list.destroy',
          ),
          1 => 
          array (
            0 => 'list',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3809 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.modal-all',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3843 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.show',
          ),
          1 => 
          array (
            0 => 'pembagian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3857 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.edit',
          ),
          1 => 
          array (
            0 => 'pembagian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3866 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.update',
          ),
          1 => 
          array (
            0 => 'pembagian',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.destroy',
          ),
          1 => 
          array (
            0 => 'pembagian',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3890 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pembagian.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3934 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.show',
          ),
          1 => 
          array (
            0 => 'jurnal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3948 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.edit',
          ),
          1 => 
          array (
            0 => 'jurnal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3957 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.update',
          ),
          1 => 
          array (
            0 => 'jurnal',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.destroy',
          ),
          1 => 
          array (
            0 => 'jurnal',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3972 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.print-show',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3995 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4033 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-simpanan.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4070 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-pinjaman.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::wKCbUpTurc4JjAiV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'broadcasting/auth',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Broadcasting\\BroadcastController@authenticate',
        'controller' => '\\Illuminate\\Broadcasting\\BroadcastController@authenticate',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'excluded_middleware' => 
        array (
          0 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
        ),
        'as' => 'generated::wKCbUpTurc4JjAiV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kwmQBGiySP7iXXx3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\API\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::kwmQBGiySP7iXXx3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RhNDG1hWIJVHLW55' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@index',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@index',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::RhNDG1hWIJVHLW55',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AXVPCAg5fDZbjLkM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/saldo-deposit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@deposit',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@deposit',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::AXVPCAg5fDZbjLkM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KHrBucijfPiBbfGu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/saldo-tarik',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@withdraw',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@withdraw',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::KHrBucijfPiBbfGu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RUukCEV5PC6aSEIL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/saldo-upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@upload_transfer',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@upload_transfer',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::RUukCEV5PC6aSEIL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EYwhQdGuiYH9ODPo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/saldo-upload-info',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@upload_info',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@upload_info',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::EYwhQdGuiYH9ODPo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kLyOxsL2FiIOzmwv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PengaturanController@index',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PengaturanController@index',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::kLyOxsL2FiIOzmwv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rIMtAUoHWPX3STZX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/pinjaman',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@index',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@index',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::rIMtAUoHWPX3STZX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::LdSJtSYZkXCUETE6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/pinjaman-history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@history',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@history',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::LdSJtSYZkXCUETE6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::i5kgxCzj50N6f39r' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/pinjaman-kode',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@kode',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@kode',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::i5kgxCzj50N6f39r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gcY7O4uBX76CqT7n' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/pinjaman-angsuran',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran_pinjaman',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran_pinjaman',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::gcY7O4uBX76CqT7n',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::V5biW61BQhREy6oJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/angsuran',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::V5biW61BQhREy6oJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KMPbDN18DdOpgSTa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/angsuran-lunas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran_lunas',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran_lunas',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::KMPbDN18DdOpgSTa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8Sa3jY3S1qJBMI4j' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/angsuran-upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@upload_transfer_angsuran',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@upload_transfer_angsuran',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::8Sa3jY3S1qJBMI4j',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RhPWsQVu4KlAefUI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/angsuran-upload-info',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@upload_info_angsuran',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@upload_info_angsuran',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::RhPWsQVu4KlAefUI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2nFpFGdQLNiUxPwa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/notifikasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@index',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@index',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::2nFpFGdQLNiUxPwa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::f4hwcwNhYx71RHO1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/notifikasi-unread',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@unread',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@unread',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::f4hwcwNhYx71RHO1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qm1ZDSPfLqAStDED' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/notifikasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@detail',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@detail',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::qm1ZDSPfLqAStDED',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::4zbnLHviRTtDxOgP' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/simpan-pinjam/notifikasi/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@delete',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\NotifikasiController@delete',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::4zbnLHviRTtDxOgP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3Ck6OCo8hOyTip7n' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-akun/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataAkunController@dataAkun',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataAkunController@dataAkun',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::3Ck6OCo8hOyTip7n',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zshN2cRAHzOoQXTN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-barang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataBarang',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataBarang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::zshN2cRAHzOoQXTN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::VAziPfpxQnvegnFB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-beli-barang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataBeliBarang',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataBeliBarang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::VAziPfpxQnvegnFB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::aR3uYl8LXYKCK84T' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-retur-barang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataReturBarang',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataReturBarang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::aR3uYl8LXYKCK84T',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7W2EPSMzR6WIwzLD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-retur-detail-barang/{nomor}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataReturDetailBarang',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataReturDetailBarang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::7W2EPSMzR6WIwzLD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gAnB6R40lGHD7SSk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-supplier/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataSupplier',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataSupplier',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::gAnB6R40lGHD7SSk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6b7d6dNEAAJu5GIk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-retur-supplier/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataReturSupplier',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataReturSupplier',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::6b7d6dNEAAJu5GIk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::st662iD2Bl4gZPhT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-hutang-supplier/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataHutangSupplier',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataHutangSupplier',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::st662iD2Bl4gZPhT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uGB3Vnw8TEW1LhmE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-anggota/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataAnggotaController@dataAnggota',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataAnggotaController@dataAnggota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::uGB3Vnw8TEW1LhmE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xGNa574XwapHXYrG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/show-notification-penjualan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@showNotification',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@showNotification',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::xGNa574XwapHXYrG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::4khHUxYwAW059KTE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/kode-admin/{jabatan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\KodeAdminController@kodeAdmin',
        'controller' => 'App\\Http\\Controllers\\Toko\\KodeAdminController@kodeAdmin',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::4khHUxYwAW059KTE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gbjDaAGAJJuhm3ee' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-pembelian/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorPembelian',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorPembelian',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::gbjDaAGAJJuhm3ee',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7x2QTWUsei2pE9lz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-pembelian/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalPembelian',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalPembelian',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::7x2QTWUsei2pE9lz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dXuLnaJ4DyvOwANd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-retur-pembelian/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorReturPembelian',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorReturPembelian',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::dXuLnaJ4DyvOwANd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6q5CR78PEZ61v1Mp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-retur-pembelian/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalReturPembelian',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalReturPembelian',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::6q5CR78PEZ61v1Mp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CZdBF0kpjethB7qS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-penjualan/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorPenjualan',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorPenjualan',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::CZdBF0kpjethB7qS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HpbJT2Lk1AOL2pTH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-penjualan/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalPenjualan',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalPenjualan',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::HpbJT2Lk1AOL2pTH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::P4EU92h6I7J8QRHh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-angsuran/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorAngsuran',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorAngsuran',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::P4EU92h6I7J8QRHh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::X5uETkaZNTg6Xxx3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-angsuran/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalAngsuran',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalAngsuran',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::X5uETkaZNTg6Xxx3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HlX2kEnGqsG1Tnvq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-terima-piutang/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorTerimaPiutang',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorTerimaPiutang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::HlX2kEnGqsG1Tnvq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::l1apK3VSSY1HFTJr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-terima-piutang/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalTerimaPiutang',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalTerimaPiutang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::l1apK3VSSY1HFTJr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::nl2VCAIOw2uHkGh7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-titip-jual/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorTitipJual',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorTitipJual',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::nl2VCAIOw2uHkGh7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mvJgCs9iOG2qHdSj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-titip-jual/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalTitipJual',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalTitipJual',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::mvJgCs9iOG2qHdSj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::85YEqC3MTmi2KlD4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-konsinyasi/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorKonsinyasi',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorKonsinyasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::85YEqC3MTmi2KlD4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yCD2WyN6nBUVRHMD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-konsinyasi/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalKonsinyasi',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalKonsinyasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::yCD2WyN6nBUVRHMD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bl0ehTPGRkZgEVX4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-umum/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalUmum',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalUmum',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::bl0ehTPGRkZgEVX4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":256:{@J84e9GQ3YdpcHOREezCNUPvyUGx3VfUBoeXcFcYLmsw=.a:5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'index\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000006f3f2275000000003759d7d5";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    't-login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\AuthController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\AuthController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 't-login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::p86fSwDm7CzcUJ5k' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/login/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\Toko\\AuthController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'generated::p86fSwDm7CzcUJ5k',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\AuthController@register',
        'controller' => 'App\\Http\\Controllers\\Toko\\AuthController@register',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wACGygB5BEXV7FRZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/register/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\AuthController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\AuthController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'generated::wACGygB5BEXV7FRZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::R28SiUWlmHwdkMLm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'generated::R28SiUWlmHwdkMLm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FfFy6E3ZrMtJ8nC7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'generated::FfFy6E3ZrMtJ8nC7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kS0GGLkAKsqqxhYm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\Toko\\AuthController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'generated::kS0GGLkAKsqqxhYm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::WKCJxVLfPhsvBCFo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/pembelian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::WKCJxVLfPhsvBCFo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::D7no64gjnACarM3f' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pembelian/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::D7no64gjnACarM3f',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::pfgbPjBG03UUa69w' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pembelian/beli',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@buy',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@buy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::pfgbPjBG03UUa69w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uLtp0TBWjYen8ZBj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pembelian/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::uLtp0TBWjYen8ZBj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hXeUTx2X9jz2oFox' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/pembelian/nota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::hXeUTx2X9jz2oFox',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ni4EwHo0mAHN9Kvw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/pembelian/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::ni4EwHo0mAHN9Kvw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::PTdTBCqLOMgFs01O' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pembelian/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::PTdTBCqLOMgFs01O',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zPqAPwqu7eJuIt0F' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/penjualan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::zPqAPwqu7eJuIt0F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yVy5egwJ3Nsfgh8g' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/penjualan/scan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@scan',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@scan',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::yVy5egwJ3Nsfgh8g',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZWGSPyRU3N9wRaL4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/penjualan/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::ZWGSPyRU3N9wRaL4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3sjD3RmywVxNZNbS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/penjualan/jual',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@sell',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@sell',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::3sjD3RmywVxNZNbS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gTLTCR1Yvv8zbihn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/penjualan/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::gTLTCR1Yvv8zbihn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Q1hRsLlETmbXbpXs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/penjualan/nota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::Q1hRsLlETmbXbpXs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::sJ6HwPcBSOE9ktXs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/penjualan/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::sJ6HwPcBSOE9ktXs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::t751Yhsa2B8eZiff' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/penjualan/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::t751Yhsa2B8eZiff',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::TCpW7Hbzcm07GMbG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/retur-pembelian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::TCpW7Hbzcm07GMbG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rdDB28oJrHv672vy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::rdDB28oJrHv672vy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5HzreNgOsVGL1UyH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/retur',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@retur',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@retur',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::5HzreNgOsVGL1UyH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mfd6DTdPg7fs7Pof' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::mfd6DTdPg7fs7Pof',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Vt8hP0oROrIx7lzZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/nota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::Vt8hP0oROrIx7lzZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FrHhnKfstFg195lw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::FrHhnKfstFg195lw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EPL2dj2doxXkKCm9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::EPL2dj2doxXkKCm9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::onRVcOLgPTJSoEtw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/hutang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Gudang,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::onRVcOLgPTJSoEtw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::UQcBMsjod3K9GNTI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/hutang/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Gudang,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::UQcBMsjod3K9GNTI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZwygNJoE9CDPgaYr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/hutang/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Gudang,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::ZwygNJoE9CDPgaYr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RZT441mVeVb18Le0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/hutang/{nomor_beli}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Gudang,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::RZT441mVeVb18Le0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uiVQXvNST8SLH5Zp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/hutang/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Gudang,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::uiVQXvNST8SLH5Zp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EZSgKCROBte65ofu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/hutang/remove-notification/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Gudang,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@removeNotification',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@removeNotification',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::EZSgKCROBte65ofu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MVwMNgPZqW1aXY6g' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/konsinyasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/konsinyasi',
        'where' => 
        array (
        ),
        'as' => 'generated::MVwMNgPZqW1aXY6g',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ydFXvPyDN5fb5f6h' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/konsinyasi/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/konsinyasi',
        'where' => 
        array (
        ),
        'as' => 'generated::ydFXvPyDN5fb5f6h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Y2oGRz8NkeHJdtzD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/konsinyasi/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/konsinyasi',
        'where' => 
        array (
        ),
        'as' => 'generated::Y2oGRz8NkeHJdtzD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zMfgOJAtMQ7nriXR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/konsinyasi/{nomor_titip_jual}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/konsinyasi',
        'where' => 
        array (
        ),
        'as' => 'generated::zMfgOJAtMQ7nriXR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Do94ktOcmcuytDbQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/konsinyasi/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/konsinyasi',
        'where' => 
        array (
        ),
        'as' => 'generated::Do94ktOcmcuytDbQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::phVIkqecpRbLfEK0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/piutang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::phVIkqecpRbLfEK0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8SfvDU9MQrYfx2t1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/piutang/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::8SfvDU9MQrYfx2t1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::L7Cvs48lZU64F2JM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/piutang/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::L7Cvs48lZU64F2JM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::h6gejjXtvERPKBQ5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/piutang/{nomor_jual}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::h6gejjXtvERPKBQ5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::eiWJQrLY0nRBTiw1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/piutang/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::eiWJQrLY0nRBTiw1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wO15QtdHwMVcuV35' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/titip-jual',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::wO15QtdHwMVcuV35',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bykYoJAKkK10qvyk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/titip-jual/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::bykYoJAKkK10qvyk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::TAStt6lR6dDW3OWo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/titip-jual/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::TAStt6lR6dDW3OWo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::f9dLQsov6nEIMqtW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/titip-jual/buy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@buy',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@buy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::f9dLQsov6nEIMqtW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oIevWzBuCDgnpfGc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/titip-jual/nota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::oIevWzBuCDgnpfGc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CAwSF72CdvCni1y8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/titip-jual/{nomor_jual}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::CAwSF72CdvCni1y8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::QV5pdJynQIjJ1w8W' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/titip-jual/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::QV5pdJynQIjJ1w8W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9AljT86hAbW9o51S' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/jurnal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Jurnal\\JurnalController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Jurnal\\JurnalController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal',
        'where' => 
        array (
        ),
        'as' => 'generated::9AljT86hAbW9o51S',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Vsp04xVc1FnOMOLp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/jurnal-umum',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::Vsp04xVc1FnOMOLp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gWVaNMSYhMTSpWUb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::gWVaNMSYhMTSpWUb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8Tol93wfYXHx8qQx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::8Tol93wfYXHx8qQx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OUYIDGlBUN24Z0Fk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@save',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@save',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::OUYIDGlBUN24Z0Fk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::R3Iqb4oUY6iyNAqd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::R3Iqb4oUY6iyNAqd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5ugaSKHcVUyDbzcF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/{nomor_jual}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::5ugaSKHcVUyDbzcF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ncPLe2mviIf5NP2k' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::ncPLe2mviIf5NP2k',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::moThFlnwGORPjY2p' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/pesanan-online',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pesanan-online',
        'where' => 
        array (
        ),
        'as' => 'generated::moThFlnwGORPjY2p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kmmxpCM6cOFQtN0A' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pesanan-online/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pesanan-online',
        'where' => 
        array (
        ),
        'as' => 'generated::kmmxpCM6cOFQtN0A',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::U6xY2jo9RNtSRUHV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pesanan-online/pickup',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@pickup',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@pickup',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pesanan-online',
        'where' => 
        array (
        ),
        'as' => 'generated::U6xY2jo9RNtSRUHV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vaZRMCUmnAiQC2CF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pesanan-online/batal-pickup',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@batalPickup',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@batalPickup',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pesanan-online',
        'where' => 
        array (
        ),
        'as' => 'generated::vaZRMCUmnAiQC2CF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jN8LF8cBuCdM3vP2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/pesanan-online/nota/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pesanan-online',
        'where' => 
        array (
        ),
        'as' => 'generated::jN8LF8cBuCdM3vP2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EGD45GyDg4geopOi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pesanan-online/proses/{id}/{proses}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@proses',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\PesananOnline\\PesananOnlineController@proses',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pesanan-online',
        'where' => 
        array (
        ),
        'as' => 'generated::EGD45GyDg4geopOi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OvXSb4Ls7bb0FHRd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/persediaan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Gudang,Kasir,Kanit',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Persediaan\\PersediaanController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Persediaan\\PersediaanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/persediaan',
        'where' => 
        array (
        ),
        'as' => 'generated::OvXSb4Ls7bb0FHRd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::UZQ3TcZWIrck00zv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/anggota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::UZQ3TcZWIrck00zv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3tEpMa9PRe7HORaT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/anggota/print/{tanggal_awal}/{tanggal_akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::3tEpMa9PRe7HORaT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ozqhg5XrdGAfiogb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/anggota/export/{tanggal_awal}/{tanggal_akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::Ozqhg5XrdGAfiogb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::1DgyHsHsKZq4uR8m' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/anggota/detail/{id}/{tanggal_awal}/{tanggal_akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@detail',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Anggota\\LaporanAnggotaController@detail',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::1DgyHsHsKZq4uR8m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xU8tRuaynnTQAjCd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/data-master',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/data-master',
        'where' => 
        array (
        ),
        'as' => 'generated::xU8tRuaynnTQAjCd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::WfaBHeWfua35wsAD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/data-master/print/{bagian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/data-master',
        'where' => 
        array (
        ),
        'as' => 'generated::WfaBHeWfua35wsAD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::l7GTkz7Hn3h0F7eY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/data-master/export/{bagian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/data-master',
        'where' => 
        array (
        ),
        'as' => 'generated::l7GTkz7Hn3h0F7eY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NgYXL2aXg6iwY5LO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pembelian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Gudang,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::NgYXL2aXg6iwY5LO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::21H304qNgxlNiOrU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pembelian/nota/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Gudang,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::21H304qNgxlNiOrU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::QOuAaoEkpeXUWuVa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pembelian/print/{type}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Gudang,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::QOuAaoEkpeXUWuVa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8YUinieIaht8POxR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pembelian/export/{type}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Gudang,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::8YUinieIaht8POxR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MxCT3UJvXZzaCFBB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/retur-pembelian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Gudang,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::MxCT3UJvXZzaCFBB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::BKesJDmb1OlBzPEA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/retur-pembelian/nota/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Gudang,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::BKesJDmb1OlBzPEA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vGial85FReRsgWmp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/retur-pembelian/print/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Gudang,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::vGial85FReRsgWmp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::D4kI2WkePNUgQKjz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/retur-pembelian/export/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Gudang,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::D4kI2WkePNUgQKjz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KuJTDIuDmXiiPxuS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/penjualan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::KuJTDIuDmXiiPxuS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Adhe7c4OA7ozOoBU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/penjualan/nota/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@nota',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@nota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::Adhe7c4OA7ozOoBU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SgGvSPVylHmAMJM9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/penjualan/print/{type}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::SgGvSPVylHmAMJM9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qQBHKLZI5Vby1zqH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/penjualan/export/{type}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::qQBHKLZI5Vby1zqH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tQFn3apJShHAiRIP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/persediaan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/persediaan',
        'where' => 
        array (
        ),
        'as' => 'generated::tQFn3apJShHAiRIP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::L75t5qyj1xsFl3xc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/persediaan/minimal-persediaan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@minimalPersediaan',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@minimalPersediaan',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/persediaan',
        'where' => 
        array (
        ),
        'as' => 'generated::L75t5qyj1xsFl3xc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::09gI3bidiZBjNkX9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/persediaan/print/{stok}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/persediaan',
        'where' => 
        array (
        ),
        'as' => 'generated::09gI3bidiZBjNkX9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::37E1jO4LUCz9IXmx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/persediaan/export/{stok}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/persediaan',
        'where' => 
        array (
        ),
        'as' => 'generated::37E1jO4LUCz9IXmx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kmjoLJB6wEzaqVGu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-masuk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Ketua_Koperasi,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-masuk',
        'where' => 
        array (
        ),
        'as' => 'generated::kmjoLJB6wEzaqVGu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::N88ertkXCVHgZOlV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-masuk/print/{jenis}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Ketua_Koperasi,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-masuk',
        'where' => 
        array (
        ),
        'as' => 'generated::N88ertkXCVHgZOlV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gupfKko18VcM10vE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-masuk/export/{jenis}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Ketua_Koperasi,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-masuk',
        'where' => 
        array (
        ),
        'as' => 'generated::gupfKko18VcM10vE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::X7Wr2v21QTRLlqVS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-keluar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Gudang,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-keluar',
        'where' => 
        array (
        ),
        'as' => 'generated::X7Wr2v21QTRLlqVS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::D27m7Q1Cef1Yv5n4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-keluar/print/{jenis}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Gudang,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-keluar',
        'where' => 
        array (
        ),
        'as' => 'generated::D27m7Q1Cef1Yv5n4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bNLoCaYIWmybfr7J' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-keluar/export/{jenis}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Gudang,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-keluar',
        'where' => 
        array (
        ),
        'as' => 'generated::bNLoCaYIWmybfr7J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::T9PxTAEsotg9MH5D' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pendapatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pendapatan\\LaporanPendapatanController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pendapatan\\LaporanPendapatanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pendapatan',
        'where' => 
        array (
        ),
        'as' => 'generated::T9PxTAEsotg9MH5D',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::V7nYnOK8L4hgdrBz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pendapatan/print/{tanggal_awal}/{tanggal_akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pendapatan\\LaporanPendapatanController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pendapatan\\LaporanPendapatanController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pendapatan',
        'where' => 
        array (
        ),
        'as' => 'generated::V7nYnOK8L4hgdrBz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GABmWobGGobbMkW6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pendapatan/export/{tanggal_awal}/{tanggal_akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pendapatan\\LaporanPendapatanController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pendapatan\\LaporanPendapatanController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pendapatan',
        'where' => 
        array (
        ),
        'as' => 'generated::GABmWobGGobbMkW6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::z8cifYbqFQm9D7py' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/piutang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Ketua_Koperasi,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Piutang\\LaporanPiutangController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Piutang\\LaporanPiutangController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::z8cifYbqFQm9D7py',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Jh2PUTG4jmDZSV8f' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/piutang/print/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Ketua_Koperasi,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Piutang\\LaporanPiutangController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Piutang\\LaporanPiutangController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::Jh2PUTG4jmDZSV8f',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EfXeuQKrllx2WQ0d' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/piutang/export/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Bendahara,Ketua_Koperasi,Kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Piutang\\LaporanPiutangController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Piutang\\LaporanPiutangController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::EfXeuQKrllx2WQ0d',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::nZZqr3dsz0SznizF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/barang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::nZZqr3dsz0SznizF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::k6Qznv2ec5xdL1OW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/barang/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::k6Qznv2ec5xdL1OW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lcr0g3RhOkLBBzZG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/barang/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::lcr0g3RhOkLBBzZG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KTHu5uEmdLfmdtE5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/barang/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@update',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::KTHu5uEmdLfmdtE5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KA8WCLbnAPE2VP4c' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/barang/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::KA8WCLbnAPE2VP4c',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZYCI9bvCUGMFehXJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/barang/barcode/{kode}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@barcode',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@barcode',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::ZYCI9bvCUGMFehXJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::BkvQvyIIz7gQ8ZYa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/barang/remove-notification/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Gudang,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@removeNotification',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@removeNotification',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::BkvQvyIIz7gQ8ZYa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::iTCdpIJpfFfhrMyl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::iTCdpIJpfFfhrMyl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rJur83z8dPVj3pC0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/admin/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::rJur83z8dPVj3pC0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::WCmpojI0aS7QmyZN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/admin/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::WCmpojI0aS7QmyZN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8KWGkNhmvxdnmeKP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/admin/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@update',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::8KWGkNhmvxdnmeKP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::DZbpUoaB3BoDJhfZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/admin/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::DZbpUoaB3BoDJhfZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yzfiW2EpEIBwKKRZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/akun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/akun',
        'where' => 
        array (
        ),
        'as' => 'generated::yzfiW2EpEIBwKKRZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8GAlk7bINRgt6AXq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/akun/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/akun',
        'where' => 
        array (
        ),
        'as' => 'generated::8GAlk7bINRgt6AXq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NzUF9M3U4JRsPC2O' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/akun/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/akun',
        'where' => 
        array (
        ),
        'as' => 'generated::NzUF9M3U4JRsPC2O',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rWynzWD18AlUFisM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/akun/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@update',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/akun',
        'where' => 
        array (
        ),
        'as' => 'generated::rWynzWD18AlUFisM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qxkv1pUMTi7dykqe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/akun/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/akun',
        'where' => 
        array (
        ),
        'as' => 'generated::qxkv1pUMTi7dykqe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZisKZLBRfxjIa3Md' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/anggota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Kanit,Super_Admin,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::ZisKZLBRfxjIa3Md',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::nWSrljkNUF0Cu1Rr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/anggota/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Kanit,Super_Admin,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::nWSrljkNUF0Cu1Rr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dgoNp4B5KLvdr4Xl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/anggota/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Kanit,Super_Admin,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::dgoNp4B5KLvdr4Xl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::QJV4Ta0WCKxUMZ5b' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/anggota/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Kanit,Super_Admin,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@update',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::QJV4Ta0WCKxUMZ5b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Q6db2JyZBjRXWqh4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/anggota/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Kanit,Super_Admin,Kasir,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::Q6db2JyZBjRXWqh4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kraJhqGVzeviXTmX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/supplier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::kraJhqGVzeviXTmX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::aCD4QlN2U2EQ2Iaq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/supplier/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::aCD4QlN2U2EQ2Iaq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::U1ACkAaIhJr7n5zd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/supplier/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::U1ACkAaIhJr7n5zd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::pqmGNBC8lpZYaiki' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/supplier/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@update',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::pqmGNBC8lpZYaiki',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OTVmXV8v9rv6jQmL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/supplier/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
          2 => 'auth:toko',
          3 => 'checkjabatan:Gudang,Super_Admin,Kanit,Ketua_Koperasi',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::OTVmXV8v9rv6jQmL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MgBpFv4XlakonQ8c' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'route-cache',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":328:{@MMs1ZDCXhi1dC2XvevwVmOimDy4xD0SIv21aHt9JOe0=.a:5:{s:3:"use";a:0:{}s:8:"function";s:115:"function () {
    \\Illuminate\\Support\\Facades\\Artisan::call(\'route:cache\');
    return \'Routes cache cleared\';
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000006f3f2246000000003759d7d5";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::MgBpFv4XlakonQ8c',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bVHg8qLA0rxH8fdy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'config-cache',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":329:{@xyZABI1Zraa7lJFOsrVMUv91L6wlcJAqcktphGimjVg=.a:5:{s:3:"use";a:0:{}s:8:"function";s:116:"function () {
    \\Illuminate\\Support\\Facades\\Artisan::call(\'config:cache\');
    return \'Config cache cleared\';
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000006f3f224d000000003759d7d5";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::bVHg8qLA0rxH8fdy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ka2w6IIkUXmiVA1a' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cache-clear',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":333:{@Hbgfl+UlQGZmV3Tri+Y8R4ASoEW9ygetcJWxowAnEnw=.a:5:{s:3:"use";a:0:{}s:8:"function";s:120:"function () {
    \\Illuminate\\Support\\Facades\\Artisan::call(\'cache:clear\');
    return \'Application cache cleared\';
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000006f3f21c9000000003759d7d5";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Ka2w6IIkUXmiVA1a',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    's-login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 's-login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'post-login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/postlogin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@post_login',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@post_login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'post-login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    's-logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 's-logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0cO565mrmGoNEcYe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":279:{@DudtfPw6EFT8FB+3Nit/eK6TnkjQmIt16MpuEBC82jY=.a:5:{s:3:"use";a:0:{}s:8:"function";s:67:"function () {
        return \\redirect()->route(\'s-login\');
    }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000006f3f2132000000003759d7d5";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::0cO565mrmGoNEcYe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'delete.simpanan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/delete-simpanan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@delete_simpanan',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@delete_simpanan',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'delete.simpanan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'delete.pinjaman' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/delete-pinjaman',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@delete_pinjaman',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@delete_pinjaman',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'delete.pinjaman',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'delete.angsuran-tempo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/delete-angsuran-tempo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@delete_angsuran',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@delete_angsuran',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'delete.angsuran-tempo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Dashboard\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Dashboard\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/master/anggota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota/{anggotum}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota/{anggotum}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/master/anggota/{anggotum}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/master/anggota/{anggotum}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
        'as' => 'anggota.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota/cetak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@print',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
        'as' => 'anggota.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/akun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/akun/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/master/akun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/akun/{akun}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/akun/{akun}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/master/akun/{akun}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/master/akun/{akun}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/akun/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
        'as' => 'akun.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/admin/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/master/admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/admin/{admin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/admin/{admin}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/master/admin/{admin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/master/admin/{admin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/admin/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
        'as' => 'admin.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/simpanan/data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/{data}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/cetak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@print',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/cetak/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.store-all' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/store-all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@store_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@store_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.store-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/konfirmasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@konfirmasi',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@konfirmasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.edit-all' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/edit-all/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@edit_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@edit_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.edit-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.image' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/image/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@modal_image',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@modal_image',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.image',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo/{saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo/{saldo}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo/{saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo/{saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.history' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/riwayat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@history',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@history',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.history',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/riwayat/cetak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@print',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/riwayat/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/{tarik_saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/{tarik_saldo}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/{tarik_saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/{tarik_saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.modal-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/modal/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@modal_delete',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@modal_delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.modal-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.saldo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@saldo',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@saldo',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.saldo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/{pengajuan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/{pengajuan}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/{pengajuan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/{pengajuan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/konfirmasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@konfirmasi',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@konfirmasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'pengajuan.konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/cetak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@print',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'pengajuan.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'pengajuan.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'pengajuan.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.limit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/limit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@limit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@limit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'pengajuan.limit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/{angsuran}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/{angsuran}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/{angsuran}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/{angsuran}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.bayar' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/bayar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@bayar',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@bayar',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.bayar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/konfirmasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@konfirmasi',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@konfirmasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.store-all' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/store-all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@store_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@store_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.store-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.update-bayar' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/update-bayar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@update_bayar',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@update_bayar',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.update-bayar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/{tempo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/{tempo}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/{tempo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/{tempo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.bayar' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/bayar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@bayar',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@bayar',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'tempo.bayar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'tempo.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/konfirmasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@konfirmasi',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@konfirmasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'tempo.konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'tempo.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.image' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/image/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@modal_image',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@modal_image',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'tempo.image',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/{jurnal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/{jurnal}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/{jurnal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/{jurnal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'jurnal.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'jurnal.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data-anggota.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/anggota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\DataAnggotaController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\DataAnggotaController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'data-anggota.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data-anggota.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/anggota/cetak/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\DataAnggotaController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\DataAnggotaController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'data-anggota.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-simpanan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/simpanan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-simpanan.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-simpanan.show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/simpanan/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-simpanan.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-simpanan.print-all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/simpanan/cetak/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@print_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@print_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-simpanan.print-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-simpanan.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/simpanan/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-simpanan.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-pinjaman.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/pinjaman',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-pinjaman.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-pinjaman.show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/pinjaman/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-pinjaman.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-pinjaman.print-all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/pinjaman/cetak/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@print_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@print_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-pinjaman.print-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-pinjaman.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/pinjaman/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-pinjaman.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'shu.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/shu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'shu.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'shu.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/shu/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'shu.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'shu.show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/shu/show-data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'shu.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'buku-besar.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/buku-besar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'buku-besar.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'buku-besar.show-data' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/buku-besar/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@show_data',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@show_data',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'buku-besar.show-data',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'buku-besar.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/buku-besar/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'buku-besar.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'ekuitas.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/ekuitas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'ekuitas.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'ekuitas.show-data' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/ekuitas/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@show_data',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@show_data',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'ekuitas.show-data',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'ekuitas.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/ekuitas/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'ekuitas.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/keuangan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'keuangan.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.show-data' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/keuangan/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@show_data',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@show_data',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'keuangan.show-data',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/keuangan/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'keuangan.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'bendahara.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/bendahara',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BendaharaController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BendaharaController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'bendahara.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'bendahara.show-data' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/bendahara/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BendaharaController@show_data',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BendaharaController@show_data',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'bendahara.show-data',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'bendahara.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/bendahara/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BendaharaController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BendaharaController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'bendahara.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/{list}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/{list}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/{list}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/{list}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.modal-all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/modal-all/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@modal_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@modal_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
        'as' => 'list.modal-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pembagian.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pembagian.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pembagian.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian/{pembagian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pembagian.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian/{pembagian}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pembagian.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian/{pembagian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pembagian.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian/{pembagian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pembagian.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pembagian.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/pembagian/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PembagianSHUController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
        'as' => 'pembagian.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'clear-notif' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pengaturan/notif',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\NotifikasiController@clear',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\NotifikasiController@clear',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
        'as' => 'clear-notif',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'all-notif' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/all-notif',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\NotifikasiController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\NotifikasiController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
        'as' => 'all-notif',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'delete-notif' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/delete-notif',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\NotifikasiController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\NotifikasiController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
        'as' => 'delete-notif',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
