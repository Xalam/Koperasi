<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H2lfrOpHHkaHiZx6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/saldo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oMFNSAfjUCBQ590g',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/saldo-deposit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::clJq1V2M7VZoElls',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/saldo-tarik' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8noyIQWE242i82ig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::u1clZ9MgIAvhKWQE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/pinjaman' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VCdIIxnNQX81LFfx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/pinjaman-history' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PEJKbUZNT17ooqq0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/pinjaman-kode' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::K8fhfrMQKa7kxL1b',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/angsuran' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SsaJUdgza3wEzdX3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/simpan-pinjam/angsuran-lunas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6UC3zJxeUWYq87G0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/show-notification-penjualan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LwGwdl6o6XWafmi2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 't-login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/login/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xUTX3xUQnxXaaRay',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/register/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e6HE8Md7MGIDHOTj',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GkQqbTIQ6blPsEIF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RPmqJoUF71puG4QQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mMEhP7YSPbRHucRP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pembelian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CScIzmEbtRHbG0tg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pembelian/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7Xl7ZReDWK3FWywU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pembelian/beli' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NGerNfvOnkgVMFBI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/pembelian/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9lDlGk08tMSoCm3Q',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qsesYrURlJnvWUnL',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::impOmvuVwinxBHXr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan/jual' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::urQP61MGFs2aR57C',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/penjualan/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oodBHylWLd61VjCx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/retur-pembelian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MT7uxMQClk2Uwkql',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/retur-pembelian/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QY2E129HtRaK0ma6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/retur-pembelian/retur' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TNbtx1WmG2Kc6OYw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/retur-pembelian/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::S7bwVP1RnslNuHF4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/hutang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rlCN0dVRPHSplO3E',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/hutang/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OJsxPX0S5oVc8Q6K',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/hutang/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sP8mUYCYRkDh1PRA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/konsinyasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Yzdwf7QL10bE5PSL',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/konsinyasi/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EwiHhXcSpUeVWuTI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/konsinyasi/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l4nNLauJao8hByYv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/piutang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::62kv2ujNR2bZxigo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/piutang/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::chDOTI6bw5FmdEsO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/piutang/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::egmHy5V6NraFU5G3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/titip-jual' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TmhmFETH18qdaosV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/titip-jual/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZyivQmd8yHHJCdMO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/titip-jual/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Pb1fZvIts8kwZW8p',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/titip-jual/buy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aLHBDQd8xodYIHiI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lf2qoQazQWkG3JVe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal-umum' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::epAu1K02Anxksqcf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal-umum/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rB1ZxWpZlSFxoChb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal-umum/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::stJQABbnBORjCnRF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal-umum/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ub8bdrN9HxQgRRAH',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/transaksi/jurnal-umum/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qpyPRWsHIhvCyUeY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/akuntansi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2hfVo3cVslCin9WO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/data-master' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::L4dV67fyVJ0eLCrI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/pembelian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kUNgz6SvZ64yQ9OQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/retur-pembelian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nfDKpM5WrizRnT50',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/penjualan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::W9LFwnwzLTdt2rnn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/persediaan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xPz2LXz5wnVWLtSs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/kas-masuk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::adRyZh4GhQtjBBu5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/kas-keluar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MuJGcFHcge26ag5b',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/laporan/pendapatan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tPXbDAYOUL8mhHPa',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/barang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6SRdAUlg9GDKL07K',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/barang/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jbYjqxRp1C7OvE6X',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/barang/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iqHWrxPAavKZVE0D',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/barang/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vRUMXbuwzcwcMuhN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/barang/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6DGusr8m7gaQVfYe',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::galxTLRyxqlWkqoN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/admin/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::63CQMdtWOqxXdggF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/admin/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lrICvfarkCjGCHxf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/admin/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cgc2ai3IyP4H5tSZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/admin/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mvJVcD2yidF2TnUy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/akun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0xATvMdMETYFKZB9',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/akun/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LQ5FW5Ofi6WkGzxp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/akun/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m20aKGt6znJpfmqj',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/akun/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M8yqI2EiL4zhLDlQ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/akun/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kFEcykxDOzE8y7pJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/anggota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1cFKy4G0UVHoGVNb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/anggota/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::klrPUvfg19GCmPwB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/anggota/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3ZSBpKHMA3RJL0fr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/anggota/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SzAG31yMIBBgtC2L',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/anggota/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xFCk7LNvNSEHFxrf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/supplier' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::y3ZDhjdw5hysHchn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/supplier/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bU19utfIwBzlfArJ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/supplier/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8SSF3YM3w7bfwQmL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/supplier/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::I1iqLixaWuz5pw3H',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/toko/master/supplier/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BTpcjYW8CWa0HIsl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 's-login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/postlogin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'post-login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 's-logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IDvcwsRtyXRHpiTV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/anggota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/anggota/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/akun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'akun.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/akun/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/master/admin/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'data.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/data/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/saldo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/saldo/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/riwayat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.history',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/tarik-saldo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/simpanan/tarik-saldo/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/pengajuan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/pengajuan/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/angsuran' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/angsuran/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/tempo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pinjaman/tempo/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/jurnal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/jurnal/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/anggota' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data-anggota.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/anggota/cetak/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data-anggota.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/simpanan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-simpanan.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/simpanan/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-simpanan.show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/simpanan/cetak/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-simpanan.print-all',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/pinjaman' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-pinjaman.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/pinjaman/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-pinjaman.show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/pinjaman/cetak/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-pinjaman.print-all',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/shu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'shu.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/shu/cetak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'shu.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/shu/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'shu.show-data',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/buku-besar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'buku-besar.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/buku-besar/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'buku-besar.show-data',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/buku-besar/cetak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'buku-besar.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/ekuitas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ekuitas.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/ekuiats/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ekuitas.show-data',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/ekuitas/cetak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ekuitas.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/keuangan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/keuangan/show' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.show-data',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/laporan/keuangan/cetak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.print-show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'list.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpan-pinjam/pengaturan/list/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/(?|data\\-(?|a(?|kun/([^/]++)(*:40)|nggota/([^/]++)(*:62))|barang/([^/]++)(*:85)|retur\\-(?|barang/([^/]++)(*:117)|detail\\-barang/([^/]++)/([^/]++)(*:157)|supplier/([^/]++)(*:182))|supplier/([^/]++)(*:208)|hutang\\-supplier/([^/]++)(*:241))|nomor\\-(?|pe(?|mbelian/([^/]++)(*:281)|njualan/([^/]++)(*:305))|jurnal\\-(?|pe(?|mbelian/([^/]++)(*:346)|njualan/([^/]++)(*:370))|retur\\-pembelian/([^/]++)(*:404)|angsuran/([^/]++)(*:429)|t(?|erima\\-piutang/([^/]++)(*:464)|itip\\-jual/([^/]++)(*:491))|konsinyasi/([^/]++)(*:519)|umum/([^/]++)(*:540))|retur\\-pembelian/([^/]++)(*:574)|angsuran/([^/]++)(*:599)|t(?|erima\\-piutang/([^/]++)(*:634)|itip\\-jual/([^/]++)(*:661))|konsinyasi/([^/]++)(*:689)))|/toko/(?|transaksi/(?|p(?|e(?|mbelian/(?|([^/]++)(*:748)|delete/([^/]++)(*:771))|njualan/(?|([^/]++)(*:799)|delete/([^/]++)(*:822)))|iutang/(?|([^/]++)(*:850)|delete/([^/]++)(*:873)))|retur\\-pembelian/(?|([^/]++)(*:911)|delete/([^/]++)(*:934))|hutang/(?|([^/]++)(*:961)|delete/([^/]++)(*:984))|konsinyasi/(?|([^/]++)(*:1015)|delete/([^/]++)(*:1039))|titip\\-jual/(?|([^/]++)(*:1072)|delete/([^/]++)(*:1096))|jurnal\\-umum/(?|([^/]++)(*:1130)|delete/([^/]++)(*:1154)))|laporan/(?|data\\-master/(?|print/([^/]++)(*:1206)|export/([^/]++)(*:1230))|pe(?|mbelian/(?|print/([^/]++)/([^/]++)/([^/]++)(*:1288)|export/([^/]++)/([^/]++)/([^/]++)(*:1330))|njualan/(?|print/([^/]++)/([^/]++)/([^/]++)(*:1383)|export/([^/]++)/([^/]++)/([^/]++)(*:1425))|rsediaan/(?|print/([^/]++)(*:1461)|export/([^/]++)(*:1485)))|retur\\-pembelian/(?|print/([^/]++)/([^/]++)(*:1539)|export/([^/]++)/([^/]++)(*:1572))|kas\\-(?|masuk/(?|print/([^/]++)/([^/]++)/([^/]++)(*:1631)|export/([^/]++)/([^/]++)/([^/]++)(*:1673))|keluar/(?|print/([^/]++)/([^/]++)/([^/]++)(*:1725)|export/([^/]++)/([^/]++)/([^/]++)(*:1767))))|master/barang/remove\\-notification/([^/]++)(*:1822))|/simpan\\-pinjam/(?|master/a(?|nggota/(?|([^/]++)(?|(*:1883)|/edit(*:1897)|(*:1906))|modal/([^/]++)(*:1930)|cetak/([^/]++)(*:1953))|kun/(?|([^/]++)(?|(*:1981)|/edit(*:1995)|(*:2004))|modal/([^/]++)(*:2028))|dmin/(?|([^/]++)(?|(*:2057)|/edit(*:2071)|(*:2080))|modal/([^/]++)(*:2104)))|simpanan/(?|data/(?|([^/]++)(?|(*:2146)|/edit(*:2160)|(*:2169))|cetak/(?|([^/]++)(*:2196)|show/([^/]++)(*:2218)|modal/([^/]++)(*:2241))|store\\-all(*:2261)|konfirmasi/([^/]++)(*:2289))|saldo/([^/]++)(?|(*:2316)|/edit(*:2330)|(*:2339))|riwayat/cetak/(?|([^/]++)(*:2374)|show/([^/]++)(*:2396))|tarik\\-saldo/(?|([^/]++)(?|(*:2433)|/edit(*:2447)|(*:2456))|modal/(?|([^/]++)(*:2483)|delete/([^/]++)(*:2507))|saldo(*:2522)))|p(?|injaman/(?|pengajuan/(?|([^/]++)(?|(*:2572)|/edit(*:2586)|(*:2595))|konfirmasi/([^/]++)(*:2624)|cetak/(?|([^/]++)(*:2650)|show/([^/]++)(*:2672))|modal/([^/]++)(*:2696)|limit(*:2710))|angsuran/(?|([^/]++)(?|(*:2743)|/edit(*:2757)|(*:2766))|bayar(*:2781)|cetak/show/([^/]++)(*:2809)|konfirmasi/([^/]++)(*:2837)|modal/([^/]++)(*:2860))|tempo/(?|([^/]++)(?|(*:2890)|/edit(*:2904)|(*:2913))|bayar(*:2928)|cetak/show/([^/]++)(*:2956)|konfirmasi/([^/]++)(*:2984)|modal/([^/]++)(*:3007)))|engaturan/list/(?|([^/]++)(?|(*:3047)|/edit(*:3061)|(*:3070))|modal\\-all/([^/]++)(*:3099)))|laporan/(?|jurnal/(?|([^/]++)(?|(*:3142)|/edit(*:3156)|(*:3165))|cetak(*:3180)|modal/([^/]++)(*:3203))|simpanan/cetak/show/([^/]++)(*:3241)|pinjaman/cetak/show/([^/]++)(*:3278))))/?$}sDu',
    ),
    3 => 
    array (
      40 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5kGk4h6TJLLYwFmW',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      62 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ufCzWQnRyt5jTdqZ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      85 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y8ECHg1rlWaSXU59',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      117 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wYPzOHY95hK1Kq9U',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      157 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dnNXwMsvz6YY2Vnk',
          ),
          1 => 
          array (
            0 => 'nomor',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      182 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UK38Pezih25fzBkb',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      208 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QggDeMNTIV5kTNE4',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      241 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fxW71aQHYopq0ENW',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      281 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VGldGBeEmTFgtwVn',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      305 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uSCn0kWx3LwRQkiL',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      346 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::U9ZyAUbSbQ8114Ge',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      370 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ciFW3zhU6Xpu9Mpq',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      404 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Yu47rVzcZGIXhZhv',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      429 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::choPNvE4B0YvUsni',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      464 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TG9VzBuPb8eiqcVy',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      491 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Qes2Z76E4OzATFFR',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      519 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hKO9sRBMALKgGJnX',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      540 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZRo4psTdpce1iSqY',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      574 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VSm9QV61qifTyEJ3',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      599 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qqk70ExnWW1ibd0F',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      634 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tplp2yRuTH7hXGbf',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      661 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cIuNBrram2zCHnPM',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      689 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wbb3YwWfjPHgY7Cl',
          ),
          1 => 
          array (
            0 => 'tanggal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      748 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eRR45Q4AuXvoCAKT',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      771 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::t3pJzUc31F6x8K5Z',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      799 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CWYpcd21VOQQdNgn',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      822 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VP7PColTM5wNaR1E',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      850 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BXkeFB1dh7p5ozOp',
          ),
          1 => 
          array (
            0 => 'nomor_jual',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      873 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XwkqfPmzRnYyFg1M',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      911 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ROjrX0Bv2TOnkLjo',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      934 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AHV9lQYhjvPMOlVO',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      961 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R71Pc0njB0fvzoG7',
          ),
          1 => 
          array (
            0 => 'nomor_beli',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      984 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Zmmaw5TBrZbPaEOK',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1015 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZpZvTOxGykByLyCI',
          ),
          1 => 
          array (
            0 => 'nomor_beli',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1039 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FuOPY9FKFUqYckld',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1072 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UkMlOA3o5Izb6AKs',
          ),
          1 => 
          array (
            0 => 'nomor_jual',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1096 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZFYxXV1hmPxjBkLY',
          ),
          1 => 
          array (
            0 => 'nomor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1130 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RtPwbUu5joVd1VNk',
          ),
          1 => 
          array (
            0 => 'nomor_jual',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1154 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1x29dWT71vMxT6iw',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1206 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sxrjnblI6N08U7Pv',
          ),
          1 => 
          array (
            0 => 'bagian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1230 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hRpJB2mPTyChOAu3',
          ),
          1 => 
          array (
            0 => 'bagian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1288 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MRLT9ALPmqPh65Pd',
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1330 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TyarPPEhff5FO7A9',
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1383 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zXqqB947EuQvUvUy',
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1425 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1rpzOPIPg2k47e6S',
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1461 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2lu2YE7n7nJBEKkB',
          ),
          1 => 
          array (
            0 => 'stok',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1485 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vepXQctVJ7LT9p8u',
          ),
          1 => 
          array (
            0 => 'stok',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1539 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Uam3524ijDJnOUEj',
          ),
          1 => 
          array (
            0 => 'awal',
            1 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1572 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XGuXy4mcKB0Pu0M3',
          ),
          1 => 
          array (
            0 => 'awal',
            1 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1631 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::u4EcYF8kc7TyYof4',
          ),
          1 => 
          array (
            0 => 'jenis',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1673 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qrBJqkb6orJXq0Qf',
          ),
          1 => 
          array (
            0 => 'jenis',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1725 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2XStXZ0XMOzvEsWE',
          ),
          1 => 
          array (
            0 => 'jenis',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1767 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9UiDXeypuKYyNVli',
          ),
          1 => 
          array (
            0 => 'jenis',
            1 => 'awal',
            2 => 'akhir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1822 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wDxCsICg1y3WLWCL',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1883 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.show',
          ),
          1 => 
          array (
            0 => 'anggotum',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1897 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.edit',
          ),
          1 => 
          array (
            0 => 'anggotum',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1906 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.update',
          ),
          1 => 
          array (
            0 => 'anggotum',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.destroy',
          ),
          1 => 
          array (
            0 => 'anggotum',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1930 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1953 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'anggota.print',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1981 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.show',
          ),
          1 => 
          array (
            0 => 'akun',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1995 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.edit',
          ),
          1 => 
          array (
            0 => 'akun',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2004 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.update',
          ),
          1 => 
          array (
            0 => 'akun',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'akun.destroy',
          ),
          1 => 
          array (
            0 => 'akun',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2028 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'akun.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2057 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.show',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2071 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2080 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.update',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.destroy',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2104 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2146 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.show',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2160 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.edit',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2169 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.update',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'data.destroy',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2196 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.print',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2218 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2241 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2261 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.store-all',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2289 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data.konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2316 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.show',
          ),
          1 => 
          array (
            0 => 'saldo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2330 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.edit',
          ),
          1 => 
          array (
            0 => 'saldo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2339 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.update',
          ),
          1 => 
          array (
            0 => 'saldo',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'saldo.destroy',
          ),
          1 => 
          array (
            0 => 'saldo',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2374 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.print',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2396 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2433 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.show',
          ),
          1 => 
          array (
            0 => 'tarik_saldo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2447 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.edit',
          ),
          1 => 
          array (
            0 => 'tarik_saldo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2456 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.update',
          ),
          1 => 
          array (
            0 => 'tarik_saldo',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.destroy',
          ),
          1 => 
          array (
            0 => 'tarik_saldo',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2483 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2507 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.modal-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2522 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tarik-saldo.saldo',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2572 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.show',
          ),
          1 => 
          array (
            0 => 'pengajuan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2586 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.edit',
          ),
          1 => 
          array (
            0 => 'pengajuan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2595 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.update',
          ),
          1 => 
          array (
            0 => 'pengajuan',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.destroy',
          ),
          1 => 
          array (
            0 => 'pengajuan',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2624 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2650 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.print',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2672 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2696 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2710 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengajuan.limit',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2743 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.show',
          ),
          1 => 
          array (
            0 => 'angsuran',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2757 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.edit',
          ),
          1 => 
          array (
            0 => 'angsuran',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2766 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.update',
          ),
          1 => 
          array (
            0 => 'angsuran',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.destroy',
          ),
          1 => 
          array (
            0 => 'angsuran',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2781 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.bayar',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2809 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2837 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2860 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'angsuran.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2890 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.show',
          ),
          1 => 
          array (
            0 => 'tempo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2904 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.edit',
          ),
          1 => 
          array (
            0 => 'tempo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2913 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.update',
          ),
          1 => 
          array (
            0 => 'tempo',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.destroy',
          ),
          1 => 
          array (
            0 => 'tempo',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2928 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.bayar',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2956 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2984 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3007 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempo.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3047 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.show',
          ),
          1 => 
          array (
            0 => 'list',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3061 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.edit',
          ),
          1 => 
          array (
            0 => 'list',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3070 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.update',
          ),
          1 => 
          array (
            0 => 'list',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'list.destroy',
          ),
          1 => 
          array (
            0 => 'list',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3099 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'list.modal-all',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3142 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.show',
          ),
          1 => 
          array (
            0 => 'jurnal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3156 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.edit',
          ),
          1 => 
          array (
            0 => 'jurnal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3165 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.update',
          ),
          1 => 
          array (
            0 => 'jurnal',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.destroy',
          ),
          1 => 
          array (
            0 => 'jurnal',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3180 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.print-show',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3203 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'jurnal.modal',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3241 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-simpanan.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3278 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lap-pinjaman.print-show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::H2lfrOpHHkaHiZx6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\API\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::H2lfrOpHHkaHiZx6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oMFNSAfjUCBQ590g' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@index',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@index',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::oMFNSAfjUCBQ590g',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::clJq1V2M7VZoElls' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/saldo-deposit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@deposit',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@deposit',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::clJq1V2M7VZoElls',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8noyIQWE242i82ig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/saldo-tarik',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@withdraw',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\SaldoController@withdraw',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::8noyIQWE242i82ig',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::u1clZ9MgIAvhKWQE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PengaturanController@index',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PengaturanController@index',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::u1clZ9MgIAvhKWQE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::VCdIIxnNQX81LFfx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/pinjaman',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@index',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@index',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::VCdIIxnNQX81LFfx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::PEJKbUZNT17ooqq0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/pinjaman-history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@history',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@history',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::PEJKbUZNT17ooqq0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::K8fhfrMQKa7kxL1b' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/simpan-pinjam/pinjaman-kode',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@kode',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@kode',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::K8fhfrMQKa7kxL1b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SsaJUdgza3wEzdX3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/angsuran',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::SsaJUdgza3wEzdX3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6UC3zJxeUWYq87G0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/simpan-pinjam/angsuran-lunas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran_lunas',
        'controller' => 'App\\Http\\Controllers\\API\\Simpan_Pinjam\\PinjamanController@angsuran_lunas',
        'namespace' => 'App\\Http\\Controllers\\API',
        'prefix' => 'api/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::6UC3zJxeUWYq87G0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5kGk4h6TJLLYwFmW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-akun/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataAkunController@dataAkun',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataAkunController@dataAkun',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::5kGk4h6TJLLYwFmW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Y8ECHg1rlWaSXU59' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-barang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataBarang',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataBarang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::Y8ECHg1rlWaSXU59',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wYPzOHY95hK1Kq9U' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-retur-barang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataReturBarang',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataReturBarang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::wYPzOHY95hK1Kq9U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dnNXwMsvz6YY2Vnk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-retur-detail-barang/{nomor}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataReturDetailBarang',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataBarangController@dataReturDetailBarang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::dnNXwMsvz6YY2Vnk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::QggDeMNTIV5kTNE4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-supplier/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataSupplier',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataSupplier',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::QggDeMNTIV5kTNE4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::UK38Pezih25fzBkb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-retur-supplier/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataReturSupplier',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataReturSupplier',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::UK38Pezih25fzBkb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fxW71aQHYopq0ENW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-hutang-supplier/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataHutangSupplier',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataSupplierController@dataHutangSupplier',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::fxW71aQHYopq0ENW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ufCzWQnRyt5jTdqZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/data-anggota/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DataAnggotaController@dataAnggota',
        'controller' => 'App\\Http\\Controllers\\Toko\\DataAnggotaController@dataAnggota',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::ufCzWQnRyt5jTdqZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::LwGwdl6o6XWafmi2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/show-notification-penjualan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@showNotification',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@showNotification',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::LwGwdl6o6XWafmi2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::VGldGBeEmTFgtwVn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-pembelian/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorPembelian',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorPembelian',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::VGldGBeEmTFgtwVn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::U9ZyAUbSbQ8114Ge' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-pembelian/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalPembelian',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalPembelian',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::U9ZyAUbSbQ8114Ge',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::VSm9QV61qifTyEJ3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-retur-pembelian/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorReturPembelian',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorReturPembelian',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::VSm9QV61qifTyEJ3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Yu47rVzcZGIXhZhv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-retur-pembelian/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalReturPembelian',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalReturPembelian',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::Yu47rVzcZGIXhZhv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uSCn0kWx3LwRQkiL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-penjualan/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorPenjualan',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorPenjualan',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::uSCn0kWx3LwRQkiL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ciFW3zhU6Xpu9Mpq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-penjualan/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalPenjualan',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalPenjualan',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::ciFW3zhU6Xpu9Mpq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qqk70ExnWW1ibd0F' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-angsuran/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorAngsuran',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorAngsuran',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::qqk70ExnWW1ibd0F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::choPNvE4B0YvUsni' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-angsuran/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalAngsuran',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalAngsuran',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::choPNvE4B0YvUsni',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tplp2yRuTH7hXGbf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-terima-piutang/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorTerimaPiutang',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorTerimaPiutang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::tplp2yRuTH7hXGbf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::TG9VzBuPb8eiqcVy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-terima-piutang/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalTerimaPiutang',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalTerimaPiutang',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::TG9VzBuPb8eiqcVy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::cIuNBrram2zCHnPM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-titip-jual/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorTitipJual',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorTitipJual',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::cIuNBrram2zCHnPM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Qes2Z76E4OzATFFR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-titip-jual/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalTitipJual',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalTitipJual',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::Qes2Z76E4OzATFFR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wbb3YwWfjPHgY7Cl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-konsinyasi/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorKonsinyasi',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorTransaksiController@nomorKonsinyasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::wbb3YwWfjPHgY7Cl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hKO9sRBMALKgGJnX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-konsinyasi/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalKonsinyasi',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalKonsinyasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::hKO9sRBMALKgGJnX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZRo4psTdpce1iSqY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nomor-jurnal-umum/{tanggal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalUmum',
        'controller' => 'App\\Http\\Controllers\\Toko\\NomorJurnalController@nomorJurnalUmum',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'generated::ZRo4psTdpce1iSqY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":256:{@hVt6fgrqNWhs+cFc252VBcJI9SxTmXa9hYkISVOEfFc=.a:5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'index\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000428b5856000000003847b58f";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    't-login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\AuthController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\AuthController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 't-login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xUTX3xUQnxXaaRay' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/login/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\Toko\\AuthController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'generated::xUTX3xUQnxXaaRay',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\AuthController@register',
        'controller' => 'App\\Http\\Controllers\\Toko\\AuthController@register',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::e6HE8Md7MGIDHOTj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/register/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\AuthController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\AuthController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'generated::e6HE8Md7MGIDHOTj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GkQqbTIQ6blPsEIF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'generated::GkQqbTIQ6blPsEIF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RPmqJoUF71puG4QQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'generated::RPmqJoUF71puG4QQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mMEhP7YSPbRHucRP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\Toko\\AuthController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/toko',
        'where' => 
        array (
        ),
        'as' => 'generated::mMEhP7YSPbRHucRP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CScIzmEbtRHbG0tg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/pembelian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::CScIzmEbtRHbG0tg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7Xl7ZReDWK3FWywU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pembelian/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::7Xl7ZReDWK3FWywU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NGerNfvOnkgVMFBI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pembelian/beli',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@buy',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@buy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::NGerNfvOnkgVMFBI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9lDlGk08tMSoCm3Q' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pembelian/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::9lDlGk08tMSoCm3Q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::eRR45Q4AuXvoCAKT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/pembelian/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::eRR45Q4AuXvoCAKT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::t3pJzUc31F6x8K5Z' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/pembelian/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Pembelian\\PembelianController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::t3pJzUc31F6x8K5Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qsesYrURlJnvWUnL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/penjualan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::qsesYrURlJnvWUnL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::impOmvuVwinxBHXr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/penjualan/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::impOmvuVwinxBHXr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::urQP61MGFs2aR57C' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/penjualan/jual',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@sell',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@sell',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::urQP61MGFs2aR57C',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oodBHylWLd61VjCx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/penjualan/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::oodBHylWLd61VjCx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CWYpcd21VOQQdNgn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/penjualan/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::CWYpcd21VOQQdNgn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::VP7PColTM5wNaR1E' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/penjualan/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Penjualan\\PenjualanController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::VP7PColTM5wNaR1E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MT7uxMQClk2Uwkql' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/retur-pembelian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::MT7uxMQClk2Uwkql',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::QY2E129HtRaK0ma6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::QY2E129HtRaK0ma6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::TNbtx1WmG2Kc6OYw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/retur',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@retur',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@retur',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::TNbtx1WmG2Kc6OYw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::S7bwVP1RnslNuHF4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::S7bwVP1RnslNuHF4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ROjrX0Bv2TOnkLjo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::ROjrX0Bv2TOnkLjo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AHV9lQYhjvPMOlVO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/retur-pembelian/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Retur\\ReturPembelianController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::AHV9lQYhjvPMOlVO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rlCN0dVRPHSplO3E' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/hutang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::rlCN0dVRPHSplO3E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OJsxPX0S5oVc8Q6K' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/hutang/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::OJsxPX0S5oVc8Q6K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::sP8mUYCYRkDh1PRA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/hutang/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::sP8mUYCYRkDh1PRA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::R71Pc0njB0fvzoG7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/hutang/{nomor_beli}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::R71Pc0njB0fvzoG7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Zmmaw5TBrZbPaEOK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/hutang/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Hutang\\HutangController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/hutang',
        'where' => 
        array (
        ),
        'as' => 'generated::Zmmaw5TBrZbPaEOK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Yzdwf7QL10bE5PSL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/konsinyasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/konsinyasi',
        'where' => 
        array (
        ),
        'as' => 'generated::Yzdwf7QL10bE5PSL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EwiHhXcSpUeVWuTI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/konsinyasi/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/konsinyasi',
        'where' => 
        array (
        ),
        'as' => 'generated::EwiHhXcSpUeVWuTI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::l4nNLauJao8hByYv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/konsinyasi/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/konsinyasi',
        'where' => 
        array (
        ),
        'as' => 'generated::l4nNLauJao8hByYv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZpZvTOxGykByLyCI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/konsinyasi/{nomor_beli}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/konsinyasi',
        'where' => 
        array (
        ),
        'as' => 'generated::ZpZvTOxGykByLyCI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FuOPY9FKFUqYckld' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/konsinyasi/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Konsinyasi\\KonsinyasiController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/konsinyasi',
        'where' => 
        array (
        ),
        'as' => 'generated::FuOPY9FKFUqYckld',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::62kv2ujNR2bZxigo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/piutang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::62kv2ujNR2bZxigo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::chDOTI6bw5FmdEsO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/piutang/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::chDOTI6bw5FmdEsO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::egmHy5V6NraFU5G3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/piutang/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::egmHy5V6NraFU5G3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::BXkeFB1dh7p5ozOp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/piutang/{nomor_jual}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::BXkeFB1dh7p5ozOp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XwkqfPmzRnYyFg1M' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/piutang/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Piutang\\PiutangController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/piutang',
        'where' => 
        array (
        ),
        'as' => 'generated::XwkqfPmzRnYyFg1M',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::TmhmFETH18qdaosV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/titip-jual',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::TmhmFETH18qdaosV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZyivQmd8yHHJCdMO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/titip-jual/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::ZyivQmd8yHHJCdMO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Pb1fZvIts8kwZW8p' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/titip-jual/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::Pb1fZvIts8kwZW8p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::aLHBDQd8xodYIHiI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/titip-jual/buy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@buy',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@buy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::aLHBDQd8xodYIHiI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::UkMlOA3o5Izb6AKs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/titip-jual/{nomor_jual}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::UkMlOA3o5Izb6AKs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZFYxXV1hmPxjBkLY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/titip-jual/delete/{nomor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\TitipJual\\TitipJualController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/titip-jual',
        'where' => 
        array (
        ),
        'as' => 'generated::ZFYxXV1hmPxjBkLY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lf2qoQazQWkG3JVe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/jurnal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Jurnal\\JurnalController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\Jurnal\\JurnalController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal',
        'where' => 
        array (
        ),
        'as' => 'generated::lf2qoQazQWkG3JVe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::epAu1K02Anxksqcf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/jurnal-umum',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::epAu1K02Anxksqcf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rB1ZxWpZlSFxoChb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::rB1ZxWpZlSFxoChb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::stJQABbnBORjCnRF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::stJQABbnBORjCnRF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ub8bdrN9HxQgRRAH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@save',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@save',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::Ub8bdrN9HxQgRRAH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qpyPRWsHIhvCyUeY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@cancel',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@cancel',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::qpyPRWsHIhvCyUeY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RtPwbUu5joVd1VNk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/{nomor_jual}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@show',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::RtPwbUu5joVd1VNk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::1x29dWT71vMxT6iw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/transaksi/jurnal-umum/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Transaksi\\JurnalUmum\\JurnalUmumController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/transaksi/jurnal-umum',
        'where' => 
        array (
        ),
        'as' => 'generated::1x29dWT71vMxT6iw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2hfVo3cVslCin9WO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/akuntansi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Akuntansi\\LaporanAkuntansiController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Akuntansi\\LaporanAkuntansiController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/akuntansi',
        'where' => 
        array (
        ),
        'as' => 'generated::2hfVo3cVslCin9WO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::L4dV67fyVJ0eLCrI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/data-master',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/data-master',
        'where' => 
        array (
        ),
        'as' => 'generated::L4dV67fyVJ0eLCrI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::sxrjnblI6N08U7Pv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/data-master/print/{bagian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/data-master',
        'where' => 
        array (
        ),
        'as' => 'generated::sxrjnblI6N08U7Pv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hRpJB2mPTyChOAu3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/data-master/export/{bagian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Master\\LaporanMasterController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/data-master',
        'where' => 
        array (
        ),
        'as' => 'generated::hRpJB2mPTyChOAu3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kUNgz6SvZ64yQ9OQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pembelian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::kUNgz6SvZ64yQ9OQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MRLT9ALPmqPh65Pd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pembelian/print/{type}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::MRLT9ALPmqPh65Pd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::TyarPPEhff5FO7A9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pembelian/export/{type}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pembelian\\LaporanPembelianController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::TyarPPEhff5FO7A9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::nfDKpM5WrizRnT50' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/retur-pembelian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::nfDKpM5WrizRnT50',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Uam3524ijDJnOUEj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/retur-pembelian/print/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::Uam3524ijDJnOUEj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XGuXy4mcKB0Pu0M3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/retur-pembelian/export/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Retur\\LaporanReturPembelianController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/retur-pembelian',
        'where' => 
        array (
        ),
        'as' => 'generated::XGuXy4mcKB0Pu0M3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::W9LFwnwzLTdt2rnn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/penjualan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::W9LFwnwzLTdt2rnn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zXqqB947EuQvUvUy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/penjualan/print/{type}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::zXqqB947EuQvUvUy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::1rpzOPIPg2k47e6S' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/penjualan/export/{type}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Penjualan\\LaporanPenjualanController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/penjualan',
        'where' => 
        array (
        ),
        'as' => 'generated::1rpzOPIPg2k47e6S',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xPz2LXz5wnVWLtSs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/persediaan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/persediaan',
        'where' => 
        array (
        ),
        'as' => 'generated::xPz2LXz5wnVWLtSs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2lu2YE7n7nJBEKkB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/persediaan/print/{stok}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/persediaan',
        'where' => 
        array (
        ),
        'as' => 'generated::2lu2YE7n7nJBEKkB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vepXQctVJ7LT9p8u' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/persediaan/export/{stok}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Persediaan\\LaporanPersediaanController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/persediaan',
        'where' => 
        array (
        ),
        'as' => 'generated::vepXQctVJ7LT9p8u',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::adRyZh4GhQtjBBu5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-masuk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-masuk',
        'where' => 
        array (
        ),
        'as' => 'generated::adRyZh4GhQtjBBu5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::u4EcYF8kc7TyYof4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-masuk/print/{jenis}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-masuk',
        'where' => 
        array (
        ),
        'as' => 'generated::u4EcYF8kc7TyYof4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qrBJqkb6orJXq0Qf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-masuk/export/{jenis}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasMasuk\\LaporanKasMasukController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-masuk',
        'where' => 
        array (
        ),
        'as' => 'generated::qrBJqkb6orJXq0Qf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MuJGcFHcge26ag5b' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-keluar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-keluar',
        'where' => 
        array (
        ),
        'as' => 'generated::MuJGcFHcge26ag5b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2XStXZ0XMOzvEsWE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-keluar/print/{jenis}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@print',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-keluar',
        'where' => 
        array (
        ),
        'as' => 'generated::2XStXZ0XMOzvEsWE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9UiDXeypuKYyNVli' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/kas-keluar/export/{jenis}/{awal}/{akhir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@export',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\KasKeluar\\LaporanKasKeluarController@export',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/kas-keluar',
        'where' => 
        array (
        ),
        'as' => 'generated::9UiDXeypuKYyNVli',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tPXbDAYOUL8mhHPa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/laporan/pendapatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pendapatan\\LaporanPendapatanController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Laporan\\Pendapatan\\LaporanPendapatanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/laporan/pendapatan',
        'where' => 
        array (
        ),
        'as' => 'generated::tPXbDAYOUL8mhHPa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6SRdAUlg9GDKL07K' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/barang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::6SRdAUlg9GDKL07K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jbYjqxRp1C7OvE6X' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/barang/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::jbYjqxRp1C7OvE6X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::iqHWrxPAavKZVE0D' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/barang/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::iqHWrxPAavKZVE0D',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vRUMXbuwzcwcMuhN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/barang/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@update',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::vRUMXbuwzcwcMuhN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6DGusr8m7gaQVfYe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/barang/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::6DGusr8m7gaQVfYe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wDxCsICg1y3WLWCL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/barang/remove-notification/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@removeNotification',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Barang\\BarangController@removeNotification',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::wDxCsICg1y3WLWCL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::galxTLRyxqlWkqoN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::galxTLRyxqlWkqoN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::63CQMdtWOqxXdggF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/admin/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::63CQMdtWOqxXdggF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lrICvfarkCjGCHxf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/admin/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::lrICvfarkCjGCHxf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::cgc2ai3IyP4H5tSZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/admin/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@update',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::cgc2ai3IyP4H5tSZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mvJVcD2yidF2TnUy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/admin/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Admin\\AdminController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::mvJVcD2yidF2TnUy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0xATvMdMETYFKZB9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/akun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/akun',
        'where' => 
        array (
        ),
        'as' => 'generated::0xATvMdMETYFKZB9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::LQ5FW5Ofi6WkGzxp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/akun/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/akun',
        'where' => 
        array (
        ),
        'as' => 'generated::LQ5FW5Ofi6WkGzxp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::m20aKGt6znJpfmqj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/akun/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/akun',
        'where' => 
        array (
        ),
        'as' => 'generated::m20aKGt6znJpfmqj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::M8yqI2EiL4zhLDlQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/akun/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@update',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/akun',
        'where' => 
        array (
        ),
        'as' => 'generated::M8yqI2EiL4zhLDlQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kFEcykxDOzE8y7pJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/akun/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Akun\\AkunController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/akun',
        'where' => 
        array (
        ),
        'as' => 'generated::kFEcykxDOzE8y7pJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::1cFKy4G0UVHoGVNb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/anggota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::1cFKy4G0UVHoGVNb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::klrPUvfg19GCmPwB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/anggota/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::klrPUvfg19GCmPwB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3ZSBpKHMA3RJL0fr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/anggota/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::3ZSBpKHMA3RJL0fr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SzAG31yMIBBgtC2L' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/anggota/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@update',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::SzAG31yMIBBgtC2L',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xFCk7LNvNSEHFxrf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/anggota/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Anggota\\AnggotaController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/anggota',
        'where' => 
        array (
        ),
        'as' => 'generated::xFCk7LNvNSEHFxrf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::y3ZDhjdw5hysHchn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/supplier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@index',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::y3ZDhjdw5hysHchn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bU19utfIwBzlfArJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'toko/master/supplier/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@create',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::bU19utfIwBzlfArJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8SSF3YM3w7bfwQmL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/supplier/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@store',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::8SSF3YM3w7bfwQmL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::I1iqLixaWuz5pw3H' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/supplier/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@update',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::I1iqLixaWuz5pw3H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::BTpcjYW8CWa0HIsl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'toko/master/supplier/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:toko',
        ),
        'uses' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@delete',
        'controller' => 'App\\Http\\Controllers\\Toko\\Master\\Supplier\\SupplierController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'toko/master/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::BTpcjYW8CWa0HIsl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    's-login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 's-login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'post-login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/postlogin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@post_login',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@post_login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'post-login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    's-logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Auth\\LoginController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 's-logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::IDvcwsRtyXRHpiTV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":279:{@Tx8T9q9fZTnIrv29qYt99Mu8cOV1Gd69kH4kJE12Pjw=.a:5:{s:3:"use";a:0:{}s:8:"function";s:67:"function () {
        return \\redirect()->route(\'s-login\');
    }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000428b5bc6000000003847b58f";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'generated::IDvcwsRtyXRHpiTV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Dashboard\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Dashboard\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/simpan-pinjam',
        'where' => 
        array (
        ),
        'as' => 'dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/master/anggota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota/{anggotum}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota/{anggotum}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/master/anggota/{anggotum}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/master/anggota/{anggotum}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'anggota.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
        'as' => 'anggota.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'anggota.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/anggota/cetak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@print',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Anggota\\AnggotaController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
        'as' => 'anggota.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/akun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/akun/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/master/akun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/akun/{akun}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/akun/{akun}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/master/akun/{akun}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/master/akun/{akun}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'akun.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'akun.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/akun/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\Akun\\AkunController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
        'as' => 'akun.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/admin/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/master/admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/admin/{admin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/admin/{admin}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/master/admin/{admin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/master/admin/{admin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
          3 => 'checkrole:admin',
        ),
        'as' => 'admin.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/master/admin/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Master\\User\\UserController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/master',
        'where' => 
        array (
        ),
        'as' => 'admin.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/simpanan/data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/{data}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'data.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/cetak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@print',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/cetak/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.store-all' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/store-all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@store_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@store_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.store-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data.konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/data/konfirmasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@konfirmasi',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SimpananController@konfirmasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'data.konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo/{saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo/{saldo}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo/{saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'saldo.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/simpanan/saldo/{saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'saldo.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\SaldoController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.history' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/riwayat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@history',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@history',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.history',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/riwayat/cetak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@print',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/riwayat/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/{tarik_saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/{tarik_saldo}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/{tarik_saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/{tarik_saldo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tarik-saldo.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.modal-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/modal/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@modal_delete',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@modal_delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.modal-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tarik-saldo.saldo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/simpanan/tarik-saldo/saldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@saldo',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Simpanan\\TarikSaldoController@saldo',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/simpanan',
        'where' => 
        array (
        ),
        'as' => 'tarik-saldo.saldo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/{pengajuan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/{pengajuan}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/{pengajuan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/{pengajuan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'pengajuan.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/konfirmasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@konfirmasi',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@konfirmasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'pengajuan.konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/cetak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@print',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@print',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'pengajuan.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'pengajuan.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'pengajuan.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pengajuan.limit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/pengajuan/limit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@limit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\PengajuanController@limit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'pengajuan.limit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/{angsuran}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/{angsuran}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/{angsuran}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/{angsuran}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'angsuran.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.bayar' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/bayar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@bayar',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@bayar',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.bayar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/konfirmasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@konfirmasi',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@konfirmasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'angsuran.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/angsuran/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\AngsuranController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'angsuran.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/{tempo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/{tempo}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/{tempo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/{tempo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'tempo.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.bayar' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/bayar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@bayar',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@bayar',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'tempo.bayar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'tempo.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/konfirmasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@konfirmasi',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@konfirmasi',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'tempo.konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempo.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pinjaman/tempo/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pinjaman\\JatuhTempoController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pinjaman',
        'where' => 
        array (
        ),
        'as' => 'tempo.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/{jurnal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/{jurnal}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/{jurnal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/{jurnal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'jurnal.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'jurnal.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'jurnal.modal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/jurnal/modal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@modal',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\JurnalUmumController@modal',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'jurnal.modal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data-anggota.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/anggota',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\DataAnggotaController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\DataAnggotaController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'data-anggota.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'data-anggota.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/anggota/cetak/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\DataAnggotaController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\DataAnggotaController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'data-anggota.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-simpanan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/simpanan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-simpanan.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-simpanan.show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/simpanan/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-simpanan.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-simpanan.print-all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/simpanan/cetak/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@print_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@print_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-simpanan.print-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-simpanan.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/simpanan/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanSimpananController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-simpanan.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-pinjaman.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/pinjaman',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-pinjaman.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-pinjaman.show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/pinjaman/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-pinjaman.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-pinjaman.print-all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/pinjaman/cetak/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@print_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@print_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-pinjaman.print-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'lap-pinjaman.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/pinjaman/cetak/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\LaporanPinjamanController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'lap-pinjaman.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'shu.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/shu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'shu.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'shu.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/shu/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'shu.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'shu.show-data' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/shu/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@show_data',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\SHUController@show_data',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'shu.show-data',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'buku-besar.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/buku-besar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'buku-besar.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'buku-besar.show-data' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/buku-besar/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@show_data',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@show_data',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'buku-besar.show-data',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'buku-besar.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/buku-besar/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\BukuBesarController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'buku-besar.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'ekuitas.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/ekuitas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'ekuitas.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'ekuitas.show-data' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/ekuiats/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@show_data',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@show_data',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'ekuitas.show-data',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'ekuitas.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/ekuitas/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\EkuitasController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'ekuitas.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/laporan/keuangan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'keuangan.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.show-data' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/keuangan/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@show_data',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@show_data',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'keuangan.show-data',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.print-show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/laporan/keuangan/cetak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@print_show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Laporan\\KeuanganController@print_show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/laporan',
        'where' => 
        array (
        ),
        'as' => 'keuangan.print-show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.index',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@index',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.create',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@create',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.store',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@store',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/{list}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.show',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@show',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@show',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/{list}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.edit',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@edit',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/{list}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.update',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@update',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/{list}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'as' => 'list.destroy',
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@destroy',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'list.modal-all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpan-pinjam/pengaturan/list/modal-all/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:simpan-pinjam',
          2 => 'checkrole:admin,bendahara,bendahara_pusat,ketua_koperasi,simpan_pinjam',
        ),
        'uses' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@modal_all',
        'controller' => 'App\\Http\\Controllers\\Simpan_Pinjam\\Pengaturan\\PengaturanController@modal_all',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'simpan-pinjam/pengaturan',
        'where' => 
        array (
        ),
        'as' => 'list.modal-all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
