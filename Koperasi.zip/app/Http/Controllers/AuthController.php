<?php

namespace App\Http\Controllers;

use App\Models\Toko\Master\Admin\AdminModel;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    public function index() {
        if (Auth::check()) {
            return redirect()->to('/toko/dashboard');
        }
        return view('toko.login');
    }

    public function login(Request $request) {
        $data = [
            'nama'     => $request->input('nama'),
            'password'  => $request->input('password'),
        ];
  
        Auth::attempt($data);
  
        if (Auth::check()) {
            return redirect()->to('/toko/dashboard');
        } else {
            Session::flash('error', 'Nama atau password salah');
            return redirect()->route('login');
        }
    }
  
    public function register() {
        return view('toko.register');
    }
    
    public function store(Request $request) {
        $create = User::create([
            'kode' => $request->input('kode'),
            'nama' => $request->input('nama'),
            'password' => Hash::make($request->input('password')),
            'jabatan' => $request->input('jabatan')
        ]);

        AdminModel::create($request->all());
  
        if($create){
            Session::flash('success', 'Register berhasil! Silahkan login untuk mengakses data');
            return redirect()->route('login');
        } else {
            Session::flash('errors', ['' => 'Register gagal! Silahkan ulangi beberapa saat lagi']);
            return redirect()->route('register');
        }
    }
  
    public function logout()
    {
        Auth::logout();
        return redirect()->route('login');
    }
}
